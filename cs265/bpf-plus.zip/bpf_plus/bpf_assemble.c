/* 
 * Copyright �1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996,
 * 1997, 2001, 2004. The Regents of the University of California 
 * (Regents). All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research, and not-for-profit purposes,
 * without fee and without a signed licensing agreement, is hereby
 * granted, provided that the above copyright notice, this paragraph and
 * the following three paragraphs appear in all copies, modifications, and
 * distributions. Contact The Office of Technology Licensing, UC
 * Berkeley, 2150 Shattuck Avenue, Suite 510, Berkeley, CA 94720-1620,
 * (510) 643-7201, for commercial licensing opportunities. 
 *
 * This code is derived from the Stanford/CMU enet packet filter,
 * distributed as part of 4.3BSD, and code contributed to Berkeley by
 * Steven McCanne and Van Jacobson both of Lawrence Berkeley Laboratory,
 * and Andrew Begel of the Berkeley Computer Science Division of the
 * Electrical Engineering and Computer Science Department.
 * 
 * IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 * SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 * REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE. THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
 * ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO
 * OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS.
 *
 *	@(#)bpf.c	7.5 (Berkeley) 7/15/91
 *
 * static char rcsid[] =
 * "$Header: /usr/src/mash/repository/bpfl/bpf_assemble.c,v 1.2 1997/11/18 00:09:41 mccanne Exp $";
 */
#if !(defined(lint) || defined(KERNEL))
static char rcsid[] =
    "@(#) $Header: /usr/src/mash/repository/bpfl/bpf_assemble.c,v 1.2 1997/11/18 00:09:41 mccanne Exp $ (LBL)";
#endif

#ifndef KERNEL
#include <stdlib.h>
#endif
#include <sys/param.h>
#include <sys/types.h>
#include <sys/time.h>

#include "bpf-vm.h"
#include "bpf_assemble.h"

/*
 * Execute the filter program starting at pc on the packet p
 * wirelen is the length of the original packet
 * buflen is the amount of data present
 */
u_char*
bpf_assemble(fc, len, mem)
	struct bpf_insn *fc;
	int len;
	u_int* mem;
{
	register int i;
	u_char **blk;
	u_char *cp;
	u_char *base;

	blk = (u_char*)malloc(len * sizeof(u_char *));
	/*XXX have maxinsn size / possibly grow buffer */
	cp = base = (u_char*)malloc(len * 20 * 4);

	cp = bpf_emit_prologue(cp, mem);
	for (i = 0; i < len; ++i) {
		struct bpf_insn *p = &fc[i];
		int op0 = p->op0;
		int op1 = p->op1;
		int code = op0 >> 24;

		/* remember where this insn starts */
		blk[i] = cp;

		switch (BPF_CLASS(code)) {

		case BPF_LD:
			cp = bpf_emit_l(cp, BPF_MODE(code),
					BPF_SIZE(code), BPF_RD(op0),
					BPF_RA(op0), op1);
			break;

		case BPF_LDM:
		  if (BPF_MODE(code) == BPF_ABS) 
		    cp = bpf_emit_lm(cp, BPF_RD(op0), op1);
		  else cp = bpf_emit_lm_index(cp, BPF_RD(op0), BPF_RA(op0));
		  break;
		  
		case BPF_STM:
		  if (BPF_MODE(code) == BPF_ABS) 
		    cp = bpf_emit_sm(cp, BPF_RD(op0), op1);
		  else cp = bpf_emit_sm_index(cp, BPF_RD(op0), BPF_RA(op0));
		  break;
		  
		case BPF_ALU:
			if (BPF_ALU_MODE(code) == BPF_IMM)
				cp = bpf_emit_alu_imm(cp, BPF_OP(code),
						      BPF_RA(op0), op1,
						      BPF_RD(op0));
			else
				cp = bpf_emit_alu_reg(cp, BPF_OP(code),
						      BPF_RA(op0),
						      BPF_RB(op1),
						      BPF_RD(op0));
			break;

		case BPF_JMP:
			if (code == (BPF_JMP|BPF_JA))
				cp = bpf_emit_ja(cp);
			else
				cp = bpf_emit_branch(cp, BPF_OP(code),
						     BPF_RD(op0), op1);
			break;

		case BPF_RET:
			if (BPF_RET_MODE(code) == BPF_IMM)
				cp = bpf_emit_ret_imm(cp, op1);
			else
				cp = bpf_emit_ret_reg(cp, BPF_RD(op0));
			break;

		default:
			abort();

		}
	}
	(void)bpf_emit_epilogue(cp);
	for (i = 0; i < len; ++i) {
	  struct bpf_insn *p = &fc[i];
	  int op0 = p->op0;
	  int code = op0 >> 24;
	  int class = BPF_CLASS(code);
	  
	  if (class == BPF_JMP) {
	    if (code == (BPF_JMP|BPF_JA))
	      bpf_patch_ja(blk[i], blk[i + p->op1 + 1]);
	    else {
	      int off = BPF_OFF(op0);
	      bpf_patch_branch(blk[i], blk[i + off + 1]);
	    }
	  } else if (class == BPF_RET) {
	    if (BPF_RET_MODE(code) == BPF_IMM)
	      bpf_patch_ret_imm(blk[i], cp);
	    else
	      bpf_patch_ret_reg(blk[i], cp);
	  }
	}
	free(blk);

	return (base);
}
