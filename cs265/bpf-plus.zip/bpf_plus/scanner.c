#include <stdio.h>
#include <stdlib.h>
# define U(x) x
# define NLSTATE yyprevious=YYNEWLINE
# define BEGIN yybgin = yysvec + 1 +
# define INITIAL 0
# define YYLERR yysvec
# define YYSTATE (yyestate-yysvec-1)
# define YYOPTIM 1
# ifndef YYLMAX 
# define YYLMAX BUFSIZ
# endif 
#ifndef __cplusplus
# define output(c) (void)putc(c,yyout)
#else
# define lex_output(c) (void)putc(c,yyout)
#endif

#if defined(__cplusplus) || defined(__STDC__)

#if defined(__cplusplus) && defined(__EXTERN_C__)
extern "C" {
#endif
	int yyback(int *, int);
	int yyinput(void);
	int yylook(void);
	void yyoutput(int);
	int yyracc(int);
	int yyreject(void);
	void yyunput(int);
	int yylex(void);
#ifdef YYLEX_E
	void yywoutput(wchar_t);
	wchar_t yywinput(void);
#endif
#ifndef yyless
	int yyless(int);
#endif
#ifndef yywrap
	int yywrap(void);
#endif
#ifdef LEXDEBUG
	void allprint(char);
	void sprint(char *);
#endif
#if defined(__cplusplus) && defined(__EXTERN_C__)
}
#endif

#ifdef __cplusplus
extern "C" {
#endif
	void exit(int);
#ifdef __cplusplus
}
#endif

#endif
# define unput(c) {yytchar= (c);if(yytchar=='\n')yylineno--;*yysptr++=yytchar;}
# define yymore() (yymorfg=1)
#ifndef __cplusplus
# define input() (((yytchar=yysptr>yysbuf?U(*--yysptr):getc(yyin))==10?(yylineno++,yytchar):yytchar)==EOF?0:yytchar)
#else
# define lex_input() (((yytchar=yysptr>yysbuf?U(*--yysptr):getc(yyin))==10?(yylineno++,yytchar):yytchar)==EOF?0:yytchar)
#endif
#define ECHO fprintf(yyout, "%s",yytext)
# define REJECT { nstr = yyreject(); goto yyfussy;}
int yyleng;
#define YYISARRAY
char yytext[YYLMAX];
int yymorfg;
extern char *yysptr, yysbuf[];
int yytchar;
FILE *yyin = {stdin}, *yyout = {stdout};
extern int yylineno;
struct yysvf { 
	struct yywork *yystoff;
	struct yysvf *yyother;
	int *yystops;};
struct yysvf *yyestate;
extern struct yysvf yysvec[], *yybgin;

# line 3 "scanner.l"
/* 
 * Copyright �1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996,
 * 1997, 2001, 2004. The Regents of the University of California 
 * (Regents). All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research, and not-for-profit purposes,
 * without fee and without a signed licensing agreement, is hereby
 * granted, provided that the above copyright notice, this paragraph and
 * the following three paragraphs appear in all copies, modifications, and
 * distributions. Contact The Office of Technology Licensing, UC
 * Berkeley, 2150 Shattuck Avenue, Suite 510, Berkeley, CA 94720-1620,
 * (510) 643-7201, for commercial licensing opportunities. 
 *
 * This code is derived from the Stanford/CMU enet packet filter,
 * distributed as part of 4.3BSD, and code contributed to Berkeley by
 * Steven McCanne and Van Jacobson both of Lawrence Berkeley Laboratory,
 * and Andrew Begel of the Berkeley Computer Science Division of the
 * Electrical Engineering and Computer Science Department.
 * 
 * IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 * SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 * REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE. THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
 * ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO
 * OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS.
 */

#ifndef lint
static char rcsid[] =
    "@(#) $Header: /usr/src/mash/repository/bpfl/scanner.l,v 1.2 1997/11/18 00:09:48 mccanne Exp $ (LBL)";
#endif

#include <sys/types.h>
#include <sys/time.h>

#include <ctype.h>
#include <unistd.h>


# line 35 "scanner.l"
/*XXX*/
#include <pcap-namedb.h>

#include "gencode.h"
#include "tokdefs.h"

static int stoi(char *);
static inline int xdtoi(int);

#ifdef FLEX_SCANNER
#undef YY_INPUT
#define YY_INPUT(buf, result, max)\
 {\
	char *src = in_buffer;\
	int i;\
\
	if (*src == 0)\
		result = YY_NULL;\
	else {\
		for (i = 0; *src && i < max; ++i)\
			buf[i] = *src++;\
		in_buffer += i;\
		result = i;\
	}\
 }
#else
#undef getc
#define getc(fp)  (*in_buffer == 0 ? EOF : *in_buffer++)
#endif

#define yylval bpfl_lval
extern YYSTYPE yylval;

static char *in_buffer;

# define YYNEWLINE 10
yylex(){
int nstr; extern int yyprevious;
#ifdef __cplusplus
/* to avoid CC and lint complaining yyfussy not being used ...*/
static int __lex_hack = 0;
if (__lex_hack) goto yyfussy;
#endif
while((nstr = yylook()) >= 0)
yyfussy: switch(nstr){
case 0:
if(yywrap()) return(0); break;
case 1:

# line 77 "scanner.l"
	return DST;
break;
case 2:

# line 78 "scanner.l"
	return SRC;
break;
case 3:

# line 80 "scanner.l"
 return LINK;
break;
case 4:

# line 81 "scanner.l"
	return LINK;
break;
case 5:

# line 82 "scanner.l"
	return ARP;
break;
case 6:

# line 83 "scanner.l"
	return RARP;
break;
case 7:

# line 84 "scanner.l"
	return IP;
break;
case 8:

# line 85 "scanner.l"
	return TCP;
break;
case 9:

# line 86 "scanner.l"
	return UDP;
break;
case 10:

# line 87 "scanner.l"
	return ICMP;
break;
case 11:

# line 88 "scanner.l"
	return IGMP;
break;
case 12:

# line 89 "scanner.l"
	return IGRP;
break;
case 13:

# line 91 "scanner.l"
	return ATALK;
break;
case 14:

# line 92 "scanner.l"
	return DECNET;
break;
case 15:

# line 93 "scanner.l"
	return LAT;
break;
case 16:

# line 94 "scanner.l"
	return SCA;
break;
case 17:

# line 95 "scanner.l"
	return MOPRC;
break;
case 18:

# line 96 "scanner.l"
	return MOPDL;
break;
case 19:

# line 98 "scanner.l"
	return HOST;
break;
case 20:

# line 99 "scanner.l"
	return NET;
break;
case 21:

# line 100 "scanner.l"
	return MASK;
break;
case 22:

# line 101 "scanner.l"
	return PORT;
break;
case 23:

# line 102 "scanner.l"
	return PROTO;
break;
case 24:

# line 104 "scanner.l"
	return GATEWAY;
break;
case 25:

# line 106 "scanner.l"
	return LESS;
break;
case 26:

# line 107 "scanner.l"
	return GREATER;
break;
case 27:

# line 108 "scanner.l"
	return BYTE;
break;
case 28:

# line 109 "scanner.l"
return TK_BROADCAST;
break;
case 29:

# line 110 "scanner.l"
return TK_MULTICAST;
break;
case 30:

# line 112 "scanner.l"
return AND;
break;
case 31:

# line 113 "scanner.l"
	return OR;
break;
case 32:

# line 114 "scanner.l"
	return '!';
break;
case 33:

# line 116 "scanner.l"
return LEN;
break;
case 34:

# line 117 "scanner.l"
	return INBOUND;
break;
case 35:

# line 118 "scanner.l"
return OUTBOUND;
break;
case 36:

# line 120 "scanner.l"
          return EVERY		;
break;
case 37:

# line 122 "scanner.l"
		;
break;
case 38:

# line 123 "scanner.l"
return yytext[0];
break;
case 39:

# line 124 "scanner.l"
		return GEQ;
break;
case 40:

# line 125 "scanner.l"
		return LEQ;
break;
case 41:

# line 126 "scanner.l"
		return NEQ;
break;
case 42:

# line 127 "scanner.l"
		return '=';
break;
case 43:

# line 128 "scanner.l"
		return LSH;
break;
case 44:

# line 129 "scanner.l"
		return RSH;
break;
case 45:

# line 130 "scanner.l"
		{ yylval.i = stoi((char *)yytext); return NUM; }
break;
case 46:

# line 131 "scanner.l"
{
			yylval.s = sdup((char *)yytext); return HID;
}
break;
case 47:

# line 134 "scanner.l"
{ yylval.e = pcap_ether_aton((char *)yytext);
			  return EID; }
break;
case 48:

# line 136 "scanner.l"
	{ bpf_error("bogus ethernet address %s", yytext); }
break;
case 49:

# line 137 "scanner.l"
{ yylval.s = sdup((char *)yytext); return ID; }
break;
case 50:

# line 138 "scanner.l"
{ yylval.s = sdup((char *)yytext + 1); return ID; }
break;
case 51:

# line 139 "scanner.l"
   { bpf_error("illegal token: %s\n", yytext); }
break;
case 52:

# line 140 "scanner.l"
		{ bpf_error("illegal char '%c'", *yytext); }
break;
case -1:
break;
default:
(void)fprintf(yyout,"bad switch yylook %d",nstr);
} return(0); }
/* end of yylex */

# line 142 "scanner.l"
void
lex_init(buf)
	char *buf;
{
	in_buffer = buf;
}

/*
 * Also define a yywrap.  Note that if we're using flex, it will
 * define a macro to map this identifier to pcap_wrap.
 */
int
yywrap()
{
	return 1;
}

/* Hex digit to integer. */
static inline int
xdtoi(c)
	register int c;
{
	if (isdigit(c))
		return c - '0';
	else if (islower(c))
		return c - 'a' + 10;
	else
		return c - 'A' + 10;
}

/*
 * Convert string to integer.  Just like atoi(), but checks for
 * preceding 0x or 0 and uses hex or octal instead of decimal.
 */
static int
stoi(s)
	char *s;
{
	int base = 10;
	int n = 0;

	if (*s == '0') {
		if (s[1] == 'x' || s[1] == 'X') {
			s += 2;
			base = 16;
		}
		else {
			base = 8;
			s += 1;
		}
	}
	while (*s)
		n = n * base + xdtoi(*s++);

	return n;
}

int yyvstop[] = {
0,

51,
52,
0, 

37,
52,
0, 

37,
0, 

38,
52,
0, 

38,
52,
0, 

38,
52,
0, 

38,
51,
52,
0, 

52,
0, 

45,
52,
0, 

45,
52,
0, 

38,
52,
0, 

38,
52,
0, 

38,
52,
0, 

49,
52,
0, 

49,
52,
0, 

51,
52,
0, 

49,
52,
0, 

49,
52,
0, 

49,
52,
0, 

49,
52,
0, 

49,
52,
0, 

49,
52,
0, 

49,
52,
0, 

49,
52,
0, 

49,
52,
0, 

49,
52,
0, 

49,
52,
0, 

49,
52,
0, 

49,
52,
0, 

49,
52,
0, 

49,
52,
0, 

49,
52,
0, 

49,
52,
0, 

38,
52,
0, 

51,
0, 

41,
0, 

30,
0, 

45,
0, 

43,
0, 

40,
0, 

42,
0, 

39,
0, 

44,
0, 

49,
0, 

49,
0, 

50,
51,
0, 

50,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

7,
49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

31,
49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

31,
0, 

46,
0, 

46,
0, 

45,
0, 

45,
0, 

30,
49,
0, 

5,
49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

1,
49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

15,
49,
0, 

33,
49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

20,
49,
0, 

32,
49,
0, 

49,
0, 

49,
0, 

3,
49,
0, 

49,
0, 

49,
0, 

16,
49,
0, 

49,
0, 

2,
49,
0, 

8,
49,
0, 

9,
49,
0, 

48,
0, 

49,
0, 

49,
0, 

27,
49,
0, 

49,
0, 

49,
0, 

49,
0, 

4,
49,
0, 

49,
0, 

49,
0, 

19,
49,
0, 

10,
49,
0, 

11,
49,
0, 

12,
49,
0, 

49,
0, 

49,
0, 

25,
49,
0, 

21,
49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

22,
49,
0, 

49,
0, 

6,
49,
0, 

46,
0, 

46,
0, 

46,
0, 

48,
0, 

13,
49,
0, 

49,
0, 

49,
0, 

36,
49,
0, 

49,
0, 

49,
0, 

49,
0, 

49,
0, 

18,
49,
0, 

17,
49,
0, 

49,
0, 

49,
0, 

23,
49,
0, 

48,
0, 

49,
0, 

14,
49,
0, 

49,
0, 

49,
0, 

49,
0, 

33,
49,
0, 

49,
0, 

49,
0, 

46,
0, 

46,
0, 

46,
0, 

49,
0, 

24,
49,
0, 

26,
49,
0, 

34,
49,
0, 

49,
0, 

49,
0, 

48,
0, 

49,
0, 

49,
0, 

35,
49,
0, 

46,
0, 

28,
49,
0, 

29,
49,
0, 

48,
0, 

47,
0, 

47,
0, 
0};
# define YYTYPE unsigned char
struct yywork { YYTYPE verify, advance; } yycrank[] = {
0,0,	0,0,	1,3,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	1,4,	1,5,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	1,6,	0,0,	
52,0,	52,0,	0,0,	1,7,	
0,0,	1,8,	1,8,	1,9,	
0,0,	0,0,	1,8,	1,10,	
7,39,	1,11,	1,12,	1,12,	
1,12,	1,12,	1,12,	1,12,	
1,12,	1,12,	1,12,	52,0,	
52,0,	1,13,	1,14,	1,15,	
0,0,	0,0,	1,16,	52,0,	
52,0,	2,8,	2,8,	6,38,	
1,17,	13,45,	13,46,	14,47,	
15,48,	15,49,	2,12,	2,12,	
2,12,	2,12,	2,12,	2,12,	
2,12,	2,12,	2,12,	43,42,	
51,42,	2,13,	2,14,	2,15,	
1,8,	1,18,	1,8,	92,133,	
96,40,	92,92,	1,19,	1,20,	
0,0,	1,21,	1,22,	1,23,	
1,24,	1,25,	1,26,	24,64,	
32,84,	1,27,	1,28,	1,29,	
1,30,	1,31,	23,63,	1,32,	
1,33,	1,34,	1,35,	34,88,	
2,8,	2,18,	2,8,	25,66,	
24,65,	1,36,	2,19,	2,20,	
20,57,	2,21,	2,22,	2,23,	
2,24,	2,25,	2,26,	20,58,	
35,89,	2,27,	2,28,	2,29,	
2,30,	2,31,	3,37,	2,32,	
2,33,	2,34,	2,35,	21,59,	
19,54,	29,77,	3,0,	3,0,	
19,55,	2,36,	19,56,	22,61,	
26,67,	22,62,	27,71,	29,78,	
26,68,	21,60,	27,72,	36,90,	
28,74,	30,79,	27,73,	26,69,	
30,80,	26,70,	54,97,	55,98,	
56,99,	3,0,	3,0,	57,100,	
58,101,	60,103,	28,75,	3,0,	
61,104,	3,0,	3,0,	3,37,	
28,76,	62,105,	3,0,	3,0,	
64,107,	3,0,	3,0,	3,0,	
3,0,	3,0,	3,0,	3,0,	
3,0,	3,0,	3,0,	65,108,	
66,109,	3,0,	3,0,	3,0,	
67,110,	69,113,	3,0,	3,0,	
3,0,	3,0,	3,0,	3,0,	
3,0,	3,0,	3,0,	3,0,	
3,0,	3,0,	3,0,	3,0,	
3,0,	3,0,	3,0,	3,0,	
3,0,	3,0,	3,0,	3,0,	
3,0,	3,0,	3,0,	3,0,	
3,0,	59,42,	3,0,	63,42,	
3,0,	71,114,	3,0,	3,0,	
3,0,	3,0,	3,0,	3,0,	
3,0,	3,0,	3,0,	3,0,	
3,0,	3,0,	3,0,	3,0,	
3,0,	3,0,	3,0,	3,0,	
3,0,	3,0,	3,0,	3,0,	
3,0,	3,0,	3,0,	3,0,	
33,85,	3,0,	9,0,	9,0,	
31,81,	31,82,	68,111,	31,83,	
73,117,	33,86,	59,102,	68,112,	
72,115,	63,106,	74,118,	33,87,	
75,119,	72,116,	76,120,	77,121,	
78,122,	80,123,	81,124,	82,125,	
83,126,	9,0,	9,0,	84,127,	
85,128,	86,129,	87,130,	9,0,	
88,131,	9,0,	9,0,	89,132,	
99,138,	100,139,	9,0,	9,0,	
101,140,	9,0,	9,0,	9,0,	
9,0,	9,0,	9,0,	9,0,	
9,0,	9,0,	9,0,	102,141,	
104,142,	9,0,	9,0,	9,0,	
105,143,	106,144,	9,0,	9,0,	
9,0,	9,0,	9,0,	9,0,	
9,0,	9,0,	9,0,	9,0,	
9,0,	9,0,	9,0,	9,0,	
9,0,	9,0,	9,0,	9,0,	
9,0,	9,0,	9,0,	9,0,	
9,0,	9,0,	9,0,	9,0,	
9,0,	107,145,	9,0,	108,146,	
9,0,	109,147,	9,0,	9,0,	
9,0,	9,0,	9,0,	9,0,	
9,0,	9,0,	9,0,	9,0,	
9,0,	9,0,	9,0,	9,0,	
9,0,	9,0,	9,0,	9,0,	
9,0,	9,0,	9,0,	9,0,	
9,0,	9,0,	9,0,	9,0,	
11,40,	9,0,	11,41,	11,41,	
11,41,	11,41,	11,41,	11,41,	
11,41,	11,41,	11,41,	11,41,	
11,42,	110,148,	111,149,	112,150,	
113,151,	115,152,	116,153,	11,43,	
11,43,	11,43,	11,43,	11,43,	
11,43,	12,40,	117,125,	12,41,	
12,41,	12,41,	12,41,	12,41,	
12,41,	12,41,	12,41,	12,41,	
12,41,	12,42,	118,154,	120,157,	
123,158,	124,159,	11,44,	126,160,	
12,43,	12,43,	12,43,	12,43,	
12,43,	12,43,	127,161,	11,43,	
11,43,	11,43,	11,43,	11,43,	
11,43,	40,91,	40,92,	40,92,	
40,92,	40,92,	40,92,	40,92,	
40,92,	40,92,	40,92,	129,125,	
135,136,	138,168,	119,155,	139,169,	
141,170,	142,125,	11,44,	143,171,	
12,43,	12,43,	12,43,	12,43,	
12,43,	12,43,	16,50,	16,50,	
119,156,	16,51,	16,51,	16,51,	
16,51,	16,51,	16,51,	16,51,	
16,51,	16,51,	16,51,	16,42,	
145,172,	146,173,	151,174,	152,175,	
155,176,	156,177,	16,51,	16,51,	
16,51,	16,51,	16,51,	16,51,	
16,50,	16,50,	16,50,	16,50,	
16,50,	16,50,	16,50,	16,50,	
16,50,	16,50,	16,50,	16,50,	
16,50,	16,50,	16,50,	16,50,	
16,50,	16,50,	16,50,	16,50,	
157,178,	158,179,	160,180,	163,181,	
16,50,	163,163,	16,51,	16,51,	
16,51,	16,51,	16,51,	16,51,	
16,50,	16,50,	16,50,	16,50,	
16,50,	16,50,	16,50,	16,50,	
16,50,	16,50,	16,50,	16,50,	
16,50,	16,50,	16,50,	16,50,	
16,50,	16,50,	16,50,	16,50,	
17,50,	17,50,	164,133,	17,50,	
17,50,	17,50,	17,50,	17,50,	
17,50,	17,50,	17,50,	17,50,	
17,50,	167,166,	169,185,	170,186,	
172,187,	173,188,	174,189,	175,190,	
17,50,	17,50,	17,50,	17,50,	
17,50,	17,50,	17,50,	17,50,	
17,50,	17,50,	17,50,	17,50,	
17,50,	17,50,	17,50,	17,50,	
17,50,	17,50,	17,50,	17,50,	
17,50,	17,50,	17,50,	17,50,	
17,50,	17,50,	178,191,	179,192,	
183,184,	185,197,	17,50,	187,198,	
17,50,	17,50,	17,50,	17,50,	
17,50,	17,50,	17,50,	17,50,	
17,50,	17,50,	17,50,	17,50,	
17,50,	17,50,	17,50,	17,50,	
17,50,	17,50,	17,50,	17,50,	
17,50,	17,50,	17,50,	17,50,	
17,50,	17,50,	18,52,	188,199,	
189,200,	191,201,	192,202,	194,194,	
195,181,	197,206,	18,0,	18,0,	
41,40,	201,207,	41,93,	41,93,	
41,93,	41,93,	41,93,	41,93,	
41,93,	41,93,	41,93,	41,93,	
41,42,	202,208,	204,205,	206,211,	
207,212,	213,214,	0,0,	0,0,	
0,0,	18,0,	18,0,	0,0,	
0,0,	0,0,	0,0,	18,53,	
0,0,	18,0,	18,0,	18,52,	
37,0,	37,0,	18,53,	18,53,	
0,0,	18,53,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	91,133,	0,0,	91,92,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	18,53,	37,0,	
37,0,	0,0,	0,0,	0,0,	
18,53,	37,0,	0,0,	37,0,	
37,0,	0,0,	0,0,	0,0,	
37,0,	37,0,	0,0,	37,0,	
37,0,	37,0,	37,0,	37,0,	
37,0,	37,0,	37,0,	37,0,	
37,0,	0,0,	0,0,	37,0,	
37,0,	37,0,	0,0,	91,134,	
37,0,	37,0,	37,0,	37,0,	
37,0,	37,0,	37,0,	37,0,	
37,0,	37,0,	37,0,	37,0,	
37,0,	37,0,	37,0,	37,0,	
37,0,	37,0,	37,0,	37,0,	
37,0,	37,0,	37,0,	37,0,	
37,0,	37,0,	37,0,	0,0,	
37,0,	0,0,	37,0,	91,134,	
37,0,	37,0,	37,0,	37,0,	
37,0,	37,0,	37,0,	37,0,	
37,0,	37,0,	37,0,	37,0,	
37,0,	37,0,	37,0,	37,0,	
37,0,	37,0,	37,0,	37,0,	
37,0,	37,0,	37,0,	37,0,	
37,0,	37,0,	0,0,	37,0,	
42,94,	42,94,	42,94,	42,94,	
42,94,	42,94,	42,94,	42,94,	
42,94,	42,94,	42,95,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	42,94,	42,94,	42,94,	
42,94,	42,94,	42,94,	44,96,	
44,96,	44,96,	44,96,	44,96,	
44,96,	44,96,	44,96,	44,96,	
44,96,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	53,53,	
44,96,	44,96,	44,96,	44,96,	
44,96,	44,96,	0,0,	53,0,	
53,0,	42,94,	42,94,	42,94,	
42,94,	42,94,	42,94,	93,40,	
193,194,	93,93,	93,93,	93,93,	
93,93,	93,93,	93,93,	93,93,	
93,93,	93,93,	93,93,	0,0,	
0,0,	0,0,	53,0,	53,0,	
44,96,	44,96,	44,96,	44,96,	
44,96,	44,96,	53,0,	53,0,	
53,53,	94,135,	94,135,	94,135,	
94,135,	94,135,	94,135,	94,135,	
94,135,	94,135,	94,135,	94,136,	
0,0,	0,0,	0,0,	0,0,	
193,203,	0,0,	94,135,	94,135,	
94,135,	94,135,	94,135,	94,135,	
95,137,	95,137,	95,137,	95,137,	
95,137,	95,137,	95,137,	95,137,	
95,137,	95,137,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	95,137,	95,137,	95,137,	
95,137,	95,137,	95,137,	0,0,	
193,203,	0,0,	94,135,	94,135,	
94,135,	94,135,	94,135,	94,135,	
133,162,	133,163,	133,163,	133,163,	
133,163,	133,163,	133,163,	133,163,	
133,163,	133,163,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	95,137,	95,137,	95,137,	
95,137,	95,137,	95,137,	134,164,	
134,164,	134,164,	134,164,	134,164,	
134,164,	134,164,	134,164,	134,164,	
134,164,	0,0,	0,0,	0,0,	
162,181,	0,0,	162,163,	0,0,	
134,164,	134,164,	134,164,	134,164,	
134,164,	134,164,	136,165,	136,165,	
136,165,	136,165,	136,165,	136,165,	
136,165,	136,165,	136,165,	136,165,	
136,166,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	136,165,	
136,165,	136,165,	136,165,	136,165,	
136,165,	0,0,	0,0,	0,0,	
134,164,	134,164,	134,164,	134,164,	
134,164,	134,164,	162,182,	0,0,	
0,0,	0,0,	0,0,	0,0,	
137,167,	137,167,	137,167,	137,167,	
137,167,	137,167,	137,167,	137,167,	
137,167,	137,167,	0,0,	136,165,	
136,165,	136,165,	136,165,	136,165,	
136,165,	137,167,	137,167,	137,167,	
137,167,	137,167,	137,167,	0,0,	
0,0,	0,0,	162,182,	181,193,	
181,194,	181,194,	181,194,	181,194,	
181,194,	181,194,	181,194,	181,194,	
181,194,	0,0,	165,183,	165,183,	
165,183,	165,183,	165,183,	165,183,	
165,183,	165,183,	165,183,	165,183,	
165,184,	137,167,	137,167,	137,167,	
137,167,	137,167,	137,167,	165,183,	
165,183,	165,183,	165,183,	165,183,	
165,183,	166,137,	166,137,	166,137,	
166,137,	166,137,	166,137,	166,137,	
166,137,	166,137,	166,137,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	166,137,	166,137,	
166,137,	166,137,	166,137,	166,137,	
0,0,	0,0,	0,0,	165,183,	
165,183,	165,183,	165,183,	165,183,	
165,183,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	182,195,	
182,195,	182,195,	182,195,	182,195,	
182,195,	182,195,	182,195,	182,195,	
182,195,	0,0,	166,137,	166,137,	
166,137,	166,137,	166,137,	166,137,	
182,195,	182,195,	182,195,	182,195,	
182,195,	182,195,	184,196,	184,196,	
184,196,	184,196,	184,196,	184,196,	
184,196,	184,196,	184,196,	184,196,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	184,196,	
184,196,	184,196,	184,196,	184,196,	
184,196,	0,0,	0,0,	0,0,	
182,195,	182,195,	182,195,	182,195,	
182,195,	182,195,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
196,204,	196,204,	196,204,	196,204,	
196,204,	196,204,	196,204,	196,204,	
196,204,	196,204,	196,205,	184,196,	
184,196,	184,196,	184,196,	184,196,	
184,196,	196,204,	196,204,	196,204,	
196,204,	196,204,	196,204,	203,209,	
203,209,	203,209,	203,209,	203,209,	
203,209,	203,209,	203,209,	203,209,	
203,209,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
203,209,	203,209,	203,209,	203,209,	
203,209,	203,209,	0,0,	0,0,	
0,0,	196,204,	196,204,	196,204,	
196,204,	196,204,	196,204,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	205,210,	205,210,	205,210,	
205,210,	205,210,	205,210,	205,210,	
205,210,	205,210,	205,210,	0,0,	
203,209,	203,209,	203,209,	203,209,	
203,209,	203,209,	205,210,	205,210,	
205,210,	205,210,	205,210,	205,210,	
210,213,	210,213,	210,213,	210,213,	
210,213,	210,213,	210,213,	210,213,	
210,213,	210,213,	210,214,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	210,213,	210,213,	210,213,	
210,213,	210,213,	210,213,	0,0,	
0,0,	0,0,	205,210,	205,210,	
205,210,	205,210,	205,210,	205,210,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	214,215,	214,215,	
214,215,	214,215,	214,215,	214,215,	
214,215,	214,215,	214,215,	214,215,	
0,0,	210,213,	210,213,	210,213,	
210,213,	210,213,	210,213,	214,215,	
214,215,	214,215,	214,215,	214,215,	
214,215,	215,216,	215,216,	215,216,	
215,216,	215,216,	215,216,	215,216,	
215,216,	215,216,	215,216,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	215,216,	215,216,	
215,216,	215,216,	215,216,	215,216,	
0,0,	0,0,	0,0,	214,215,	
214,215,	214,215,	214,215,	214,215,	
214,215,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	215,216,	215,216,	
215,216,	215,216,	215,216,	215,216,	
0,0};
struct yysvf yysvec[] = {
0,	0,	0,
yycrank+-1,	0,		0,	
yycrank+-29,	yysvec+1,	0,	
yycrank+-141,	0,		yyvstop+1,
yycrank+0,	0,		yyvstop+4,
yycrank+0,	0,		yyvstop+7,
yycrank+10,	0,		yyvstop+9,
yycrank+10,	0,		yyvstop+12,
yycrank+0,	0,		yyvstop+15,
yycrank+-257,	yysvec+3,	yyvstop+18,
yycrank+0,	0,		yyvstop+22,
yycrank+334,	0,		yyvstop+24,
yycrank+359,	0,		yyvstop+27,
yycrank+13,	0,		yyvstop+30,
yycrank+14,	0,		yyvstop+33,
yycrank+15,	0,		yyvstop+36,
yycrank+417,	0,		yyvstop+39,
yycrank+495,	0,		yyvstop+42,
yycrank+-617,	0,		yyvstop+45,
yycrank+38,	yysvec+16,	yyvstop+48,
yycrank+14,	yysvec+16,	yyvstop+51,
yycrank+46,	yysvec+16,	yyvstop+54,
yycrank+39,	yysvec+16,	yyvstop+57,
yycrank+14,	yysvec+16,	yyvstop+60,
yycrank+10,	yysvec+17,	yyvstop+63,
yycrank+12,	yysvec+17,	yyvstop+66,
yycrank+57,	yysvec+17,	yyvstop+69,
yycrank+61,	yysvec+17,	yyvstop+72,
yycrank+67,	yysvec+17,	yyvstop+75,
yycrank+48,	yysvec+17,	yyvstop+78,
yycrank+51,	yysvec+17,	yyvstop+81,
yycrank+157,	yysvec+17,	yyvstop+84,
yycrank+11,	yysvec+17,	yyvstop+87,
yycrank+165,	yysvec+17,	yyvstop+90,
yycrank+20,	yysvec+17,	yyvstop+93,
yycrank+36,	yysvec+17,	yyvstop+96,
yycrank+39,	0,		yyvstop+99,
yycrank+-651,	yysvec+3,	yyvstop+102,
yycrank+0,	0,		yyvstop+104,
yycrank+0,	0,		yyvstop+106,
yycrank+389,	0,		0,	
yycrank+582,	0,		yyvstop+108,
yycrank+728,	0,		0,	
yycrank+29,	0,		0,	
yycrank+751,	0,		0,	
yycrank+0,	0,		yyvstop+110,
yycrank+0,	0,		yyvstop+112,
yycrank+0,	0,		yyvstop+114,
yycrank+0,	0,		yyvstop+116,
yycrank+0,	0,		yyvstop+118,
yycrank+0,	yysvec+17,	yyvstop+120,
yycrank+30,	yysvec+17,	yyvstop+122,
yycrank+-27,	yysvec+18,	yyvstop+124,
yycrank+-814,	yysvec+18,	yyvstop+127,
yycrank+70,	yysvec+17,	yyvstop+129,
yycrank+59,	yysvec+17,	yyvstop+131,
yycrank+75,	yysvec+17,	yyvstop+133,
yycrank+64,	yysvec+17,	yyvstop+135,
yycrank+60,	yysvec+17,	yyvstop+137,
yycrank+175,	yysvec+17,	yyvstop+139,
yycrank+61,	yysvec+17,	yyvstop+141,
yycrank+76,	yysvec+17,	yyvstop+143,
yycrank+84,	yysvec+17,	yyvstop+145,
yycrank+177,	yysvec+17,	yyvstop+147,
yycrank+72,	yysvec+17,	yyvstop+149,
yycrank+98,	yysvec+17,	yyvstop+151,
yycrank+85,	yysvec+17,	yyvstop+153,
yycrank+95,	yysvec+17,	yyvstop+155,
yycrank+161,	yysvec+17,	yyvstop+157,
yycrank+107,	yysvec+17,	yyvstop+159,
yycrank+0,	yysvec+17,	yyvstop+161,
yycrank+121,	yysvec+17,	yyvstop+164,
yycrank+166,	yysvec+17,	yyvstop+166,
yycrank+162,	yysvec+17,	yyvstop+168,
yycrank+163,	yysvec+17,	yyvstop+170,
yycrank+168,	yysvec+17,	yyvstop+172,
yycrank+174,	yysvec+17,	yyvstop+174,
yycrank+167,	yysvec+17,	yyvstop+176,
yycrank+168,	yysvec+17,	yyvstop+178,
yycrank+0,	yysvec+17,	yyvstop+180,
yycrank+169,	yysvec+17,	yyvstop+183,
yycrank+172,	yysvec+17,	yyvstop+185,
yycrank+175,	yysvec+17,	yyvstop+187,
yycrank+177,	yysvec+17,	yyvstop+189,
yycrank+177,	yysvec+17,	yyvstop+191,
yycrank+195,	yysvec+17,	yyvstop+193,
yycrank+188,	yysvec+17,	yyvstop+195,
yycrank+195,	yysvec+17,	yyvstop+197,
yycrank+184,	yysvec+17,	yyvstop+199,
yycrank+187,	yysvec+17,	yyvstop+201,
yycrank+0,	0,		yyvstop+203,
yycrank+627,	yysvec+40,	yyvstop+205,
yycrank+49,	yysvec+40,	yyvstop+207,
yycrank+785,	0,		yyvstop+209,
yycrank+809,	0,		0,	
yycrank+832,	yysvec+42,	0,	
yycrank+50,	yysvec+44,	yyvstop+211,
yycrank+0,	yysvec+17,	yyvstop+213,
yycrank+0,	yysvec+17,	yyvstop+216,
yycrank+192,	yysvec+17,	yyvstop+219,
yycrank+204,	yysvec+17,	yyvstop+221,
yycrank+203,	yysvec+17,	yyvstop+223,
yycrank+205,	yysvec+17,	yyvstop+225,
yycrank+0,	yysvec+17,	yyvstop+227,
yycrank+215,	yysvec+17,	yyvstop+230,
yycrank+206,	yysvec+17,	yyvstop+232,
yycrank+216,	yysvec+17,	yyvstop+234,
yycrank+248,	yysvec+17,	yyvstop+236,
yycrank+254,	yysvec+17,	yyvstop+238,
yycrank+237,	yysvec+17,	yyvstop+240,
yycrank+281,	yysvec+17,	yyvstop+242,
yycrank+282,	yysvec+17,	yyvstop+244,
yycrank+283,	yysvec+17,	yyvstop+246,
yycrank+285,	yysvec+17,	yyvstop+248,
yycrank+0,	yysvec+17,	yyvstop+250,
yycrank+294,	yysvec+17,	yyvstop+253,
yycrank+283,	yysvec+17,	yyvstop+256,
yycrank+299,	yysvec+17,	yyvstop+258,
yycrank+311,	yysvec+17,	yyvstop+260,
yycrank+350,	yysvec+17,	yyvstop+262,
yycrank+303,	yysvec+17,	yyvstop+264,
yycrank+0,	yysvec+17,	yyvstop+266,
yycrank+0,	yysvec+17,	yyvstop+269,
yycrank+322,	yysvec+17,	yyvstop+272,
yycrank+305,	yysvec+17,	yyvstop+274,
yycrank+0,	yysvec+17,	yyvstop+276,
yycrank+307,	yysvec+17,	yyvstop+279,
yycrank+318,	yysvec+17,	yyvstop+281,
yycrank+0,	yysvec+17,	yyvstop+283,
yycrank+335,	yysvec+17,	yyvstop+286,
yycrank+0,	yysvec+17,	yyvstop+288,
yycrank+0,	yysvec+17,	yyvstop+291,
yycrank+0,	yysvec+17,	yyvstop+294,
yycrank+864,	0,		0,	
yycrank+887,	0,		0,	
yycrank+390,	0,		0,	
yycrank+910,	0,		yyvstop+297,
yycrank+948,	yysvec+136,	0,	
yycrank+342,	yysvec+17,	yyvstop+299,
yycrank+351,	yysvec+17,	yyvstop+301,
yycrank+0,	yysvec+17,	yyvstop+303,
yycrank+351,	yysvec+17,	yyvstop+306,
yycrank+339,	yysvec+17,	yyvstop+308,
yycrank+334,	yysvec+17,	yyvstop+310,
yycrank+0,	yysvec+17,	yyvstop+312,
yycrank+357,	yysvec+17,	yyvstop+315,
yycrank+361,	yysvec+17,	yyvstop+317,
yycrank+0,	yysvec+17,	yyvstop+319,
yycrank+0,	yysvec+17,	yyvstop+322,
yycrank+0,	yysvec+17,	yyvstop+325,
yycrank+0,	yysvec+17,	yyvstop+328,
yycrank+361,	yysvec+17,	yyvstop+331,
yycrank+363,	yysvec+17,	yyvstop+333,
yycrank+0,	yysvec+17,	yyvstop+335,
yycrank+0,	yysvec+17,	yyvstop+338,
yycrank+372,	yysvec+17,	yyvstop+341,
yycrank+382,	yysvec+17,	yyvstop+343,
yycrank+403,	yysvec+17,	yyvstop+345,
yycrank+398,	yysvec+17,	yyvstop+347,
yycrank+0,	yysvec+17,	yyvstop+349,
yycrank+399,	yysvec+17,	yyvstop+352,
yycrank+0,	yysvec+17,	yyvstop+354,
yycrank+902,	yysvec+133,	yyvstop+357,
yycrank+465,	yysvec+133,	yyvstop+359,
yycrank+496,	yysvec+134,	yyvstop+361,
yycrank+986,	0,		0,	
yycrank+1009,	yysvec+136,	yyvstop+363,
yycrank+495,	0,		0,	
yycrank+0,	yysvec+17,	yyvstop+365,
yycrank+455,	yysvec+17,	yyvstop+368,
yycrank+439,	yysvec+17,	yyvstop+370,
yycrank+0,	yysvec+17,	yyvstop+372,
yycrank+459,	yysvec+17,	yyvstop+375,
yycrank+456,	yysvec+17,	yyvstop+377,
yycrank+448,	yysvec+17,	yyvstop+379,
yycrank+455,	yysvec+17,	yyvstop+381,
yycrank+0,	yysvec+17,	yyvstop+383,
yycrank+0,	yysvec+17,	yyvstop+386,
yycrank+487,	yysvec+17,	yyvstop+389,
yycrank+470,	yysvec+17,	yyvstop+391,
yycrank+0,	yysvec+17,	yyvstop+393,
yycrank+975,	0,		0,	
yycrank+1047,	0,		0,	
yycrank+530,	0,		0,	
yycrank+1070,	yysvec+136,	yyvstop+396,
yycrank+492,	yysvec+17,	yyvstop+398,
yycrank+0,	yysvec+17,	yyvstop+400,
yycrank+470,	yysvec+17,	yyvstop+403,
yycrank+505,	yysvec+17,	yyvstop+405,
yycrank+520,	yysvec+17,	yyvstop+407,
yycrank+0,	yysvec+17,	yyvstop+409,
yycrank+524,	yysvec+17,	yyvstop+412,
yycrank+512,	yysvec+17,	yyvstop+414,
yycrank+784,	yysvec+181,	yyvstop+416,
yycrank+575,	yysvec+181,	yyvstop+418,
yycrank+578,	yysvec+182,	yyvstop+420,
yycrank+1108,	0,		0,	
yycrank+510,	yysvec+17,	yyvstop+422,
yycrank+0,	yysvec+17,	yyvstop+424,
yycrank+0,	yysvec+17,	yyvstop+427,
yycrank+0,	yysvec+17,	yyvstop+430,
yycrank+514,	yysvec+17,	yyvstop+433,
yycrank+541,	yysvec+17,	yyvstop+435,
yycrank+1131,	0,		0,	
yycrank+584,	0,		0,	
yycrank+1169,	yysvec+136,	yyvstop+437,
yycrank+527,	yysvec+17,	yyvstop+439,
yycrank+528,	yysvec+17,	yyvstop+441,
yycrank+0,	yysvec+17,	yyvstop+443,
yycrank+0,	yysvec+203,	yyvstop+446,
yycrank+1192,	0,		0,	
yycrank+0,	yysvec+17,	yyvstop+448,
yycrank+0,	yysvec+17,	yyvstop+451,
yycrank+587,	0,		0,	
yycrank+1230,	yysvec+136,	yyvstop+454,
yycrank+1253,	yysvec+136,	yyvstop+456,
yycrank+0,	yysvec+167,	yyvstop+458,
0,	0,	0};
struct yywork *yytop = yycrank+1355;
struct yysvf *yybgin = yysvec+1;
char yymatch[] = {
  0,   1,   1,   1,   1,   1,   1,   1, 
  1,   9,  10,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  9,  33,   1,   1,   1,   1,  38,   1, 
 33,  33,  42,  42,   1,  45,  46,  42, 
 48,  48,  48,  48,  48,  48,  48,  48, 
 48,  48,  42,   1,  38,  38,  38,   1, 
  1,  65,  65,  65,  65,  65,  65,  71, 
 71,  71,  71,  71,  71,  71,  71,  71, 
 71,  71,  71,  71,  71,  71,  71,  71, 
 71,  71,  71,  38,   1,  38,   1,  46, 
  1,  65,  65,  65,  65,  65,  65,  71, 
 71,  71,  71,  71,  71,  71,  71,  71, 
 71,  71,  71,  71,  71,  71,  71,  71, 
 71,  71,  71,   1,  38,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
0};
char yyextra[] = {
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0};
/*	Copyright (c) 1989 AT&T	*/
/*	  All Rights Reserved  	*/

/*	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF AT&T	*/
/*	The copyright notice above does not evidence any   	*/
/*	actual or intended publication of such source code.	*/

#pragma ident	"@(#)ncform	6.11	97/01/06 SMI"

int yylineno =1;
# define YYU(x) x
# define NLSTATE yyprevious=YYNEWLINE
struct yysvf *yylstate [YYLMAX], **yylsp, **yyolsp;
char yysbuf[YYLMAX];
char *yysptr = yysbuf;
int *yyfnd;
extern struct yysvf *yyestate;
int yyprevious = YYNEWLINE;
#if defined(__cplusplus) || defined(__STDC__)
int yylook(void)
#else
yylook()
#endif
{
	register struct yysvf *yystate, **lsp;
	register struct yywork *yyt;
	struct yysvf *yyz;
	int yych, yyfirst;
	struct yywork *yyr;
# ifdef LEXDEBUG
	int debug;
# endif
	char *yylastch;
	/* start off machines */
# ifdef LEXDEBUG
	debug = 0;
# endif
	yyfirst=1;
	if (!yymorfg)
		yylastch = yytext;
	else {
		yymorfg=0;
		yylastch = yytext+yyleng;
		}
	for(;;){
		lsp = yylstate;
		yyestate = yystate = yybgin;
		if (yyprevious==YYNEWLINE) yystate++;
		for (;;){
# ifdef LEXDEBUG
			if(debug)fprintf(yyout,"state %d\n",yystate-yysvec-1);
# endif
			yyt = yystate->yystoff;
			if(yyt == yycrank && !yyfirst){  /* may not be any transitions */
				yyz = yystate->yyother;
				if(yyz == 0)break;
				if(yyz->yystoff == yycrank)break;
				}
#ifndef __cplusplus
			*yylastch++ = yych = input();
#else
			*yylastch++ = yych = lex_input();
#endif
#ifdef YYISARRAY
			if(yylastch > &yytext[YYLMAX]) {
				fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
				exit(1);
			}
#else
			if (yylastch >= &yytext[ yytextsz ]) {
				int	x = yylastch - yytext;

				yytextsz += YYTEXTSZINC;
				if (yytext == yy_tbuf) {
				    yytext = (char *) malloc(yytextsz);
				    memcpy(yytext, yy_tbuf, sizeof (yy_tbuf));
				}
				else
				    yytext = (char *) realloc(yytext, yytextsz);
				if (!yytext) {
				    fprintf(yyout,
					"Cannot realloc yytext\n");
				    exit(1);
				}
				yylastch = yytext + x;
			}
#endif
			yyfirst=0;
		tryagain:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"char ");
				allprint(yych);
				putchar('\n');
				}
# endif
			yyr = yyt;
			if ( (int)yyt > (int)yycrank){
				yyt = yyr + yych;
				if (yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					if(lsp > &yylstate[YYLMAX]) {
						fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
						exit(1);
					}
					goto contin;
					}
				}
# ifdef YYOPTIM
			else if((int)yyt < (int)yycrank) {		/* r < yycrank */
				yyt = yyr = yycrank+(yycrank-yyt);
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"compressed state\n");
# endif
				yyt = yyt + yych;
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					if(lsp > &yylstate[YYLMAX]) {
						fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
						exit(1);
					}
					goto contin;
					}
				yyt = yyr + YYU(yymatch[yych]);
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"try fall back character ");
					allprint(YYU(yymatch[yych]));
					putchar('\n');
					}
# endif
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transition */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					if(lsp > &yylstate[YYLMAX]) {
						fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
						exit(1);
					}
					goto contin;
					}
				}
			if ((yystate = yystate->yyother) && (yyt= yystate->yystoff) != yycrank){
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"fall back to state %d\n",yystate-yysvec-1);
# endif
				goto tryagain;
				}
# endif
			else
				{unput(*--yylastch);break;}
		contin:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"state %d char ",yystate-yysvec-1);
				allprint(yych);
				putchar('\n');
				}
# endif
			;
			}
# ifdef LEXDEBUG
		if(debug){
			fprintf(yyout,"stopped at %d with ",*(lsp-1)-yysvec-1);
			allprint(yych);
			putchar('\n');
			}
# endif
		while (lsp-- > yylstate){
			*yylastch-- = 0;
			if (*lsp != 0 && (yyfnd= (*lsp)->yystops) && *yyfnd > 0){
				yyolsp = lsp;
				if(yyextra[*yyfnd]){		/* must backup */
					while(yyback((*lsp)->yystops,-*yyfnd) != 1 && lsp > yylstate){
						lsp--;
						unput(*yylastch--);
						}
					}
				yyprevious = YYU(*yylastch);
				yylsp = lsp;
				yyleng = yylastch-yytext+1;
				yytext[yyleng] = 0;
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"\nmatch ");
					sprint(yytext);
					fprintf(yyout," action %d\n",*yyfnd);
					}
# endif
				return(*yyfnd++);
				}
			unput(*yylastch);
			}
		if (yytext[0] == 0  /* && feof(yyin) */)
			{
			yysptr=yysbuf;
			return(0);
			}
#ifndef __cplusplus
		yyprevious = yytext[0] = input();
		if (yyprevious>0)
			output(yyprevious);
#else
		yyprevious = yytext[0] = lex_input();
		if (yyprevious>0)
			lex_output(yyprevious);
#endif
		yylastch=yytext;
# ifdef LEXDEBUG
		if(debug)putchar('\n');
# endif
		}
	}
#if defined(__cplusplus) || defined(__STDC__)
int yyback(int *p, int m)
#else
yyback(p, m)
	int *p;
#endif
{
	if (p==0) return(0);
	while (*p) {
		if (*p++ == m)
			return(1);
	}
	return(0);
}
	/* the following are only used in the lex library */
#if defined(__cplusplus) || defined(__STDC__)
int yyinput(void)
#else
yyinput()
#endif
{
#ifndef __cplusplus
	return(input());
#else
	return(lex_input());
#endif
	}
#if defined(__cplusplus) || defined(__STDC__)
void yyoutput(int c)
#else
yyoutput(c)
  int c; 
#endif
{
#ifndef __cplusplus
	output(c);
#else
	lex_output(c);
#endif
	}
#if defined(__cplusplus) || defined(__STDC__)
void yyunput(int c)
#else
yyunput(c)
   int c; 
#endif
{
	unput(c);
	}
