/* 
 * Copyright �1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996,
 * 1997, 2001, 2004. The Regents of the University of California 
 * (Regents). All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research, and not-for-profit purposes,
 * without fee and without a signed licensing agreement, is hereby
 * granted, provided that the above copyright notice, this paragraph and
 * the following three paragraphs appear in all copies, modifications, and
 * distributions. Contact The Office of Technology Licensing, UC
 * Berkeley, 2150 Shattuck Avenue, Suite 510, Berkeley, CA 94720-1620,
 * (510) 643-7201, for commercial licensing opportunities. 
 *
 * This code is derived from the Stanford/CMU enet packet filter,
 * distributed as part of 4.3BSD, and code contributed to Berkeley by
 * Steven McCanne and Van Jacobson both of Lawrence Berkeley Laboratory,
 * and Andrew Begel of the Berkeley Computer Science Division of the
 * Electrical Engineering and Computer Science Department.
 * 
 * IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 * SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 * REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE. THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
 * ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO
 * OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS.
 *
 * @(#) $Header: /usr/src/mash/repository/bpfl/gencode.h,v 1.4 1997/11/20 17:39:28 mccanne Exp $ (LBL)
 */

#ifndef gencode_h
#define gencode_h

#include "bpf-vm.h"

/* Address qualifers. */

#define Q_HOST		1
#define Q_NET		2
#define Q_PORT		3
#define Q_GATEWAY	4
#define Q_PROTO		5

/* Protocol qualifiers. */

#define Q_LINK		1
#define Q_IP		2
#define Q_ARP		3
#define Q_RARP		4
#define Q_TCP		5
#define Q_UDP		6
#define Q_ICMP		7
#define Q_IGMP		8
#define Q_IGRP		9

#define	Q_ATALK		10
#define	Q_DECNET	11
#define	Q_LAT		12
#define Q_SCA		13
#define	Q_MOPRC		14
#define	Q_MOPDL		15

/* Directional qualifers. */

#define Q_SRC		1
#define Q_DST		2
#define Q_OR		3
#define Q_AND		4

#define Q_DEFAULT	0
#define Q_UNDEF		255

struct stmt {
	int code;
	int ra;
	int rb;
	int rd;
	int32_t imm;
};

struct slist {
	struct stmt s;
	struct slist *next;
};


/*
 * An unbounded set.
 */
typedef u_long *uset;

/* 
 * A bit vector to represent definition sets for pseudo registers.
 * All computation is performed using temporary variables called
 * pseudo-registers.  The register allocator maps an unbounded
 * number of pseudo registers onto the finite set of VM registers
 * as the last stage of code generation.  If there is too much
 * register contention, pseudo registers are spilled to scratch 
 * memory.
 */
#define MAX_PSEUDO_REGS 1024
#define N_PSEUDO_REGS 32
typedef struct {
  u_long reg;
  u_long mem;
} atomset;

#define MEMATOM(memlocation) (get_num_reg() + memlocation)

struct edge {
  int id;
  uset edom;
  struct block *succ;
  struct block *pred;
  struct edge *next;	/* link list of incoming edges for a node */
};

struct block {
  int id;
  struct slist *stmts;	/* side effect stmts */
  struct stmt s;		/* branch insn */
  int mark;
  int level;
  int offset;
  int sense;
  struct edge et;
  struct edge ef;
  struct block *head;
  struct block *link;	/* link field used by optimizer */
  uset dom;
  uset closure;
  uset def, kill, in_use, out_use;
  struct edge *in_edges;
};

struct arth {
	struct block *b;	/* protocol checks */
	struct slist *s;	/* stmt list */
	int regno;		/* virtual register number of result */
};

struct qual {
	unsigned char addr;
	unsigned char proto;
	unsigned char dir;
	unsigned char pad;
};



/* XXX */
#define JT(b)  ((b)->et.succ)
#define JF(b)  ((b)->ef.succ)

#define BITS_PER_WORD (8*sizeof(u_long))

/*
 * a[*] = val
 */
#define SET_SET(a, val, n)\
{\
	register u_long *_x = a;\
	register int _n = n;\
	while (--_n >= 0) *_x++ = val;\
}

/*
 * a := b
 */
#define SET_COPY(a, b, n)\
{\
	register u_long *_x = a, *_y = b;\
	register int _n = n;\
	while (--_n >= 0) *_x++ = *_y++;\
}

/*
 * True if a is in uset {p}
 */
#define SET_MEMBER(p, a) \
((p)[(unsigned)(a) / BITS_PER_WORD] & (1 << ((unsigned)(a) % BITS_PER_WORD)))

/*
 * Add 'a' to uset p.
 */
#define SET_INSERT(p, a) \
(p)[(unsigned)(a) / BITS_PER_WORD] |= (1 << ((unsigned)(a) % BITS_PER_WORD))



/*
 * Delete 'a' from uset p.
 */
#define SET_DELETE(p, a) \
(p)[(unsigned)(a) / BITS_PER_WORD] &= ~(1 << ((unsigned)(a) % BITS_PER_WORD))

/*
 * a := a intersect b
 */
#define SET_INTERSECT(a, b, n)\
{\
	register u_long *_x = a, *_y = b;\
	register int _n = n;\
	while (--_n >= 0) *_x++ &= *_y++;\
}

/*
 * a := a - b
 */
#define SET_SUBTRACT(a, b, n)\
{\
	register u_long *_x = a, *_y = b;\
	register int _n = n;\
	while (--_n >= 0) *_x++ &=~ *_y++;\
}

/*
 * a := a union b
 */
#define SET_UNION(a, b, n)\
{\
	register u_long *_x = a, *_y = b;\
	register int _n = n;\
	while (--_n >= 0) *_x++ |= *_y++;\
}
/*
 * a := a union (b - c)
 */
#define SET_UNION_SUBTRACT(a, b, c, n)\
{\
   register u_long *_x = a, *_y = b, *_z = c;\
   register int _n = n;\
   while (--_n >= 0) *_x++ |= (*_y++ &~ *_z++);\
}

struct arth *gen_loadi(int);
struct arth *gen_load(int, struct arth *, int);
struct arth *gen_loadlen(void);
struct arth *gen_neg(struct arth *);
struct arth *gen_arth(int, struct arth *, struct arth *);

void gen_and(struct block *, struct block *);
void gen_or(struct block *, struct block *);
void gen_not(struct block *);

struct block *gen_scode(char *, struct qual);
struct block *gen_ecode(u_char *, struct qual);
struct block *gen_mcode(const char *, const char *, int, struct qual);
struct block *gen_ncode(const char *, u_long, struct qual);
struct block *gen_proto_abbrev(int);
struct block *gen_relation(int, struct arth *, struct arth *, int);
struct block *gen_less(int);
struct block *gen_greater(int);
struct block *gen_byteop(int, int, int);
struct block *gen_broadcast(int);
struct block *gen_multicast(int);
struct block *gen_inbound(int);
struct block *gen_every(struct arth *);

void bpf_optimize(struct block **);
void bpf_dont_optimize(struct block **);
/*__dead*/ 
    void bpf_error(const char *, ...)
    __attribute__((volatile, format (printf, 1, 2)));

void finish_parse(struct block *);
char *sdup(char *);

struct bpf_insn *icode_to_fcode(struct block *, int *);
int pcap_parse(void);
void lex_init(char *);
void sappend(struct slist *, struct slist *);

void total_redundancy_elimination();
void replace_register(int, int);
void liveness(struct stmt *s, struct block *b);
void register_allocation();
char *opt_image(struct block *b, struct stmt *s);
static void topsort_r(struct block *p);
static void topsort(struct block *p);


int get_num_mem();
int get_num_reg();

#endif
