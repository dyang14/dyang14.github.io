/* 
 * Copyright �1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996,
 * 1997, 2001, 2004. The Regents of the University of California 
 * (Regents). All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research, and not-for-profit purposes,
 * without fee and without a signed licensing agreement, is hereby
 * granted, provided that the above copyright notice, this paragraph and
 * the following three paragraphs appear in all copies, modifications, and
 * distributions. Contact The Office of Technology Licensing, UC
 * Berkeley, 2150 Shattuck Avenue, Suite 510, Berkeley, CA 94720-1620,
 * (510) 643-7201, for commercial licensing opportunities. 
 *
 * This code is derived from the Stanford/CMU enet packet filter,
 * distributed as part of 4.3BSD, and code contributed to Berkeley by
 * Steven McCanne and Van Jacobson both of Lawrence Berkeley Laboratory,
 * and Andrew Begel of the Berkeley Computer Science Division of the
 * Electrical Engineering and Computer Science Department.
 * 
 * IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 * SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 * REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE. THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
 * ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO
 * OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS.
 */

#ifndef lint
static char rcsid[] =
	"@(#) $Header: /usr/src/mash/repository/bpfl/bpf_image.c,v 1.4 1997/11/19 01:50:34 mccanne Exp $ (LBL)";
#endif

#include <sys/types.h>
#include <sys/time.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "bpf-vm.h"

char *
bpf_image(p, n)
	struct bpf_insn *p;
	int n;
{
	int code;
	u_int op0, ra, rb, rd;
	int op1;
	int a0, a1, a2;
	char *fmt, *op;
	static char image[256];/*XXX non re-entrant*/
	char operand[64];

	op1 = p->op1;
	op0 = p->op0;
	// Debugging info. 5 bits isn't enough.
	//ra = p->ra;
	//rb = p->rb;
	//rd = p->rd;
	code = op0 >> 24;

	switch (BPF_CLASS(code)) {
	case BPF_ALU:
		if (BPF_ALU_MODE(code) == BPF_IMM) {
			fmt = "r%d, 0x%x, r%d";
			a0 = BPF_RA(op0);
			a1 = op1;
			a2 = BPF_RD(op0);
		} else {
			fmt = "r%d, r%d, r%d";
			a0 = BPF_RA(op0);
			a1 = BPF_RB(op0);
			a2 = BPF_RD(op0);
		}
		break;

	case BPF_LD:
		if (BPF_MODE(code) == BPF_ABS) {
			fmt = "[%d], r%d";
			a0 = op1;
			a1 = BPF_RD(op0);
		} else {
			fmt = "[r%d + %d], r%d";
			a0 = BPF_RA(op0);
			a1 = op1;
			a2 = BPF_RD(op0);
		}
		break;

	case BPF_JMP:
	  if (BPF_ALU_MODE(code) ==  BPF_IMM) {
	    fmt = "r%d, 0x%x, L%d";
	    a0 = BPF_RD(op0);
	    a1 = op1;
	    a2 = n + BPF_OFF(op0) + 1;
	  }
	  else {
	    fmt = "r%d, r%d, L%d";
	    a0 = BPF_RD(op0);
	    a1 = BPF_RA(op0);
	    a2 = n + BPF_OFF(op0) + 1;
	  }
	  break;
	}
	switch (code) {

	  //	default:
	  //	op = "unimp";
	  //	fmt = "0x%x";
	  //	a0 = code;
	  //	break;

	case BPF_RET|BPF_IMM:
		op = "ret";
		fmt = "%d";
		a0 = op1;
		break;

	case BPF_RET|BPF_REG:
		op = "ret";
		fmt = "r%d";
		a0 = BPF_RD(op0);
		break;

	case BPF_LD|BPF_W|BPF_ABS:
		op = "l";
		break;

	case BPF_LD|BPF_H|BPF_ABS:
		op = "lh";
		break;

	case BPF_LD|BPF_B|BPF_ABS:
		op = "lb";
		break;

	case BPF_LD|BPF_W|BPF_IND:
		op = "l";
		break;

	case BPF_LD|BPF_H|BPF_IND:
		op = "lh";
		break;

	case BPF_LD|BPF_B|BPF_IND:
		op = "lb";
		break;

	case BPF_LD|BPF_IMM:
		op = "li";
		fmt = "0x%x, r%d";
		a0 = op1;
		a1 = BPF_RD(op0);
		break;

	case BPF_LDM:
		op = "lm";
		fmt = "M[%d], r%d";
		a0 = op1;
		a1 = BPF_RD(op0);
		break;

	case BPF_STM:
		op = "sm";
		fmt = "r%d, M[%d]";
		a0 = BPF_RD(op0);
		a1 = op1;
		break;

	case BPF_JMP|BPF_JA:
		op = "ja";
		fmt = "L%d";
		a0 = n + op1 + 1;
		break;

	case BPF_JMP|BPF_JGT|BPF_REG:
	case BPF_JMP|BPF_JGT|BPF_IMM:
		op = "jgt";
		break;

	case BPF_JMP|BPF_JGE|BPF_REG:
	case BPF_JMP|BPF_JGE|BPF_IMM:
		op = "jge";
		break;

	case BPF_JMP|BPF_JEQ|BPF_REG:
	case BPF_JMP|BPF_JEQ|BPF_IMM:
		op = "jeq";
		break;

	case BPF_JMP|BPF_JLT|BPF_REG:
	case BPF_JMP|BPF_JLT|BPF_IMM:
		op = "jlt";
		break;

	case BPF_JMP|BPF_JLE|BPF_REG:
	case BPF_JMP|BPF_JLE|BPF_IMM:
		op = "jle";
		break;

	case BPF_JMP|BPF_JNE|BPF_REG:
	case BPF_JMP|BPF_JNE|BPF_IMM:
		op = "jne";
		break;

	case BPF_ALU|BPF_ADD|BPF_REG:
	case BPF_ALU|BPF_ADD|BPF_IMM:
		op = "add";
		break;

	case BPF_ALU|BPF_SUB|BPF_REG:
	case BPF_ALU|BPF_SUB|BPF_IMM:
		op = "sub";
		break;

	case BPF_ALU|BPF_MUL|BPF_REG:
	case BPF_ALU|BPF_MUL|BPF_IMM:
		op = "mul";
		break;

	case BPF_ALU|BPF_DIV|BPF_REG:
	case BPF_ALU|BPF_DIV|BPF_IMM:
		op = "div";
		break;

	case BPF_ALU|BPF_AND|BPF_REG:
	case BPF_ALU|BPF_AND|BPF_IMM:
		op = "and";
		break;

	case BPF_ALU|BPF_OR|BPF_REG:
	case BPF_ALU|BPF_OR|BPF_IMM:
		op = "or";
		break;

	case BPF_ALU|BPF_LSH|BPF_REG:
	case BPF_ALU|BPF_LSH|BPF_IMM:
		op = "lsh";
		break;

	case BPF_ALU|BPF_RSH|BPF_REG:
	case BPF_ALU|BPF_RSH|BPF_IMM:
		op = "rsh";
		break;
	}
		
	(void)sprintf(operand, fmt, a0, a1, a2);
	(void)sprintf(image, "\t%-8s %s", op, operand);
	return (image);
}

void
bpf_dump(struct bpf_insn *insn, int n)
{
	int i;
	int nlabel;
	u_char* target;
	
	target = malloc(n);
	memset(target, 0, n);
	for (i = 0; i < n; ++i) {
		u_int32_t op0 = insn[i].op0;
		u_int32_t op1 = insn[i].op1;
		if (BPF_CLASS(op0 >> 24) == BPF_JMP) {
		  if ( (op0>>24) == (BPF_JMP|BPF_JA)) {
		    int k = i + op1 + 1;
		    if ((unsigned)k < n) target[k] = 1;
		  }
		  else {
		    int k = i + BPF_OFF(op0) + 1;
		    if ((unsigned)k < n)
		      target[k] = 1;
		  }
		}
	}
	for (i = 0; i < n; ++insn, ++i) {
		if (target[i]) 
			printf("L%d:\n", i);
#ifdef OPT_DEBUGA
		extern int bids[];
		printf(bids[i] > 0 ? "[%02d]" : " -- ", bids[i] - 1);
#endif
		puts(bpf_image(insn, i));
	}
}
