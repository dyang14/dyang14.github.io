/* 
 * Copyright �1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996,
 * 1997, 2001, 2004. The Regents of the University of California 
 * (Regents). All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research, and not-for-profit purposes,
 * without fee and without a signed licensing agreement, is hereby
 * granted, provided that the above copyright notice, this paragraph and
 * the following three paragraphs appear in all copies, modifications, and
 * distributions. Contact The Office of Technology Licensing, UC
 * Berkeley, 2150 Shattuck Avenue, Suite 510, Berkeley, CA 94720-1620,
 * (510) 643-7201, for commercial licensing opportunities. 
 *
 * This code is derived from the Stanford/CMU enet packet filter,
 * distributed as part of 4.3BSD, and code contributed to Berkeley by
 * Steven McCanne and Van Jacobson both of Lawrence Berkeley Laboratory,
 * and Andrew Begel of the Berkeley Computer Science Division of the
 * Electrical Engineering and Computer Science Department.
 * 
 * IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 * SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 * REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE. THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
 * ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO
 * OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS.
 */

int main(int argc, char** argv) {

  int compare, result;

  if (argc > 1) { 
    argv++;
    compare = atoi(*argv);
  }
  printf("%d\n", compare);
  printf("%d, %d, %d\n", compare & 0xf, compare & 0xf0, compare & 0xf00);

  result = (((compare & 0xf) == 3) && (((compare & 0xf0) >> 4) == 4) && 
	    (((compare & 0xf00) >> 8) == 6)) ||
    (((compare & 0xf) == 3) && (((compare & 0xf0) >> 4) == 4) && 
     (((compare & 0xf00) >> 8) == 7));
  printf("result is %s\n", (result) ? "true" : "false");

}
