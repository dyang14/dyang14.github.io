/* 
 * Copyright �1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996,
 * 1997, 2001, 2004. The Regents of the University of California 
 * (Regents). All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research, and not-for-profit purposes,
 * without fee and without a signed licensing agreement, is hereby
 * granted, provided that the above copyright notice, this paragraph and
 * the following three paragraphs appear in all copies, modifications, and
 * distributions. Contact The Office of Technology Licensing, UC
 * Berkeley, 2150 Shattuck Avenue, Suite 510, Berkeley, CA 94720-1620,
 * (510) 643-7201, for commercial licensing opportunities. 
 *
 * This code is derived from the Stanford/CMU enet packet filter,
 * distributed as part of 4.3BSD, and code contributed to Berkeley by
 * Steven McCanne and Van Jacobson both of Lawrence Berkeley Laboratory,
 * and Andrew Begel of the Berkeley Computer Science Division of the
 * Electrical Engineering and Computer Science Department.
 * 
 * IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 * SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 * REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE. THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
 * ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO
 * OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS.
 */

#ifndef lint
static char rcsid[] =
    "@(#) $Header: /usr/src/mash/repository/bpfl/scanner.l,v 1.2 1997/11/18 00:09:48 mccanne Exp $ (LBL)";
#endif

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>

#include <net/if.h>

#include <netinet/in.h>
#include <netinet/if_ether.h>

#include <stdlib.h>
#include <memory.h>
#include <setjmp.h>
#include <stdio.h>
#include <stdarg.h>

#include "bpf-vm.h"
#include "gencode.h"
#include "value_numbering.h"

static valnode value_list[MAX_PSEUDO_REGS];
static u_long value_mask[MAX_PSEUDO_REGS/BITS_PER_WORD] ;
static nodewords = 0;

void init_val(int ndwds) {
  int i;
  u_long *space = (u_long *)malloc(MAX_PSEUDO_REGS * ndwds * sizeof(*space));
  nodewords = ndwds;

  for (i= 0; i< MAX_PSEUDO_REGS; i++) {
    value_list[i].dest = make_dest(DEST_UNDEFINED, 0);
    value_list[i].interference = space;
    SET_SET(value_list[i].interference, 0, ndwds);
    space += ndwds;
  }
  for (i = 0; i < (MAX_PSEUDO_REGS / BITS_PER_WORD); i++) {
    value_mask[i] = 0;
  }
  

}

int instruction_equalp(instruction i1, instruction i2) {
  if (i1.type != i2.type) return 0;
  switch(i1.type) {
  case IT_IMM:
    return (i1.instr.imm.imm == i2.instr.imm.imm);
  case IT_PACKET:
    return (i1.instr.packet.start == i2.instr.packet.start &&
	    i1.instr.packet.length == i2.instr.packet.length);
  case IT_PACKET_REG:
    return (i1.instr.packet_reg.reg == i2.instr.packet_reg.reg &&
	    i1.instr.packet_reg.start == i2.instr.packet_reg.start &&
	    i1.instr.packet_reg.length == i2.instr.packet_reg.length);
  case IT_MEM: 
    return (i1.instr.mem.location == i2.instr.mem.location &&
	    i1.instr.mem.code == i2.instr.mem.code &&
	    i1.instr.mem.reg == i2.instr.mem.reg);
  case IT_REG_REG:
    return (i1.instr.reg_reg.code == i2.instr.reg_reg.code &&
	    i1.instr.reg_reg.reg1 == i2.instr.reg_reg.reg1 &&
	    i1.instr.reg_reg.reg2 == i2.instr.reg_reg.reg2);
  case IT_REG_IMM:
    return (i1.instr.reg_imm.code == i2.instr.reg_imm.code &&
	    i1.instr.reg_imm.reg == i2.instr.reg_imm.reg &&
	    i1.instr.reg_imm.imm == i2.instr.reg_imm.imm);
  case IT_JMP:
    return (i1.instr.jmp.reg == i2.instr.jmp.reg &&
	    i1.instr.jmp.imm == i2.instr.jmp.imm);
  case IT_UNDEFINED:
    return 0;
  }
}

instruction valnum_instruction(struct stmt *s) {
  instruction output;

  switch (BPF_CLASS(s->code)) {
  case BPF_LD: 
    if (s->code == BPF_LD|BPF_IMM) {
      output.type = IT_IMM;
      output.instr.imm.imm = s->imm;
    }
    else if (BPF_MODE(s->code) == BPF_ABS) {
      output.type = IT_PACKET;
      output.instr.packet.start = s->imm;
      switch(BPF_SIZE(s->code)) {
      case BPF_B: 
	output.instr.packet.length = 1;
	break;
      case BPF_H:
	output.instr.packet.length = 2;
	break;
      case BPF_W: 
	output.instr.packet.length = 4;
	break;
      }
    }
    else {
      output.type = IT_PACKET_REG;
      output.instr.packet_reg.reg = s->ra;
      output.instr.packet_reg.start = s->imm;
      switch(BPF_SIZE(s->code)) {
      case BPF_B: 
	output.instr.packet_reg.length = 1;
	break;
      case BPF_H:
	output.instr.packet_reg.length = 2;
	break;
      case BPF_W: 
	output.instr.packet_reg.length = 4;
	break;
      }
    }
    break;
      
  case BPF_LDM:
  case BPF_STM:
    output.type = IT_MEM;
    output.instr.mem.location = s->imm;
    output.instr.mem.code = s->code;
    if (BPF_CLASS(s->code) == BPF_STM) 
      output.instr.mem.reg = s->rd;
    else output.instr.mem.reg = -1;
    break;
  case BPF_ALU:
    if (BPF_ALU_MODE(s->code) == BPF_REG) {
      output.type = IT_REG_REG;
      output.instr.reg_reg.reg1 = s->ra;
      output.instr.reg_reg.reg2 = s->rb;
      output.instr.reg_reg.code = s->code;
    }
    else {
      output.type = IT_REG_IMM;
      output.instr.reg_imm.reg = s->ra;
      output.instr.reg_imm.imm = s->imm;
      output.instr.reg_imm.code = s->code;
    }
    break;

  case BPF_JMP:
    output.type = IT_JMP;
    output.instr.jmp.reg = s->rd;
    output.instr.jmp.imm = s->imm;
    break;
  case BPF_RET:
    output.type = IT_UNDEFINED;
    break;
  }
  return output;
}

destination valnum_destination(struct stmt *s) {
  destination output;

  switch (BPF_CLASS(s->code)) {
  case BPF_LD: 
  case BPF_LDM:
  case BPF_ALU:
    output.type = DEST_REG;
    output.place = s->rd;
    break;
  case BPF_STM:
    output.type = DEST_MEM;
    output.place = s->imm;
    break;
  case BPF_JMP:
  case BPF_RET:
    output.type = DEST_UNDEFINED;
    output.place = 0;
    break;
  }
  return output;
}

int valnum(destination d) {
  switch(d.type) {
  case DEST_REG:
    return d.place;
  case DEST_MEM:
    return get_num_reg() + d.place;
  }
  return -1;
}

valnode *find_dest(destination d) {
  return &value_list[valnum(d)];
}

void erase_dest(destination d) {
  int index = valnum(d);
  value_list[index].dest.type = DEST_UNDEFINED;
}

int is_constantp(instruction code) {
  return (code.type == IT_IMM);
}

valnode *find_earliest(struct stmt *s) {

  instruction ins = valnum_instruction(s);
  valnode *best = &value_list[valnum(valnum_destination(s))];
  int i;

  for (i = 0; i < MAX_PSEUDO_REGS; i++) {
    if (value_list[i].dest.type != DEST_UNDEFINED) {
      if (instruction_equalp(value_list[i].instr, ins)) {
	if (SET_MEMBER(best->b->dom, value_list[i].b->id)) {
	  best = &value_list[i];
	}
      }
    }
  }
  return best;
}

destination make_dest(unsigned int type, unsigned int place) {
  destination output;
  output.type = type;
  output.place = place;
  return output;
}

void insert_valnode(valnode v) {
  int valn = valnum(v.dest);
  value_list[valn].instr = v.instr;
  value_list[valn].dest = v.dest;
  value_list[valn].b = v.b;
  SET_SET(value_list[valn].interference, 0, nodewords);
  SET_INSERT(value_mask, valn);
}

void overwrite_valnode(valnode v) {
  int valn = valnum(v.dest);
  value_list[valn].instr = v.instr;
  value_list[valn].dest = v.dest;
  value_list[valn].b = v.b;
  SET_UNION(value_list[valn].interference, v.interference, nodewords); 
  SET_INSERT(value_mask, valn);
}


valnode make_valnode(struct block *b, struct stmt *s) {
  valnode output;

  output.instr = valnum_instruction(s);
  output.dest = valnum_destination(s);
  output.b = b;
  return output;

}

valnode *find_valnode(int reg) {
  return &(value_list[reg]);
}
