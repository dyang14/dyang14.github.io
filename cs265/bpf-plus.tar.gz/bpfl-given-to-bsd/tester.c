/* 
 * Copyright �1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996,
 * 1997, 2001, 2004. The Regents of the University of California 
 * (Regents). All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research, and not-for-profit purposes,
 * without fee and without a signed licensing agreement, is hereby
 * granted, provided that the above copyright notice, this paragraph and
 * the following three paragraphs appear in all copies, modifications, and
 * distributions. Contact The Office of Technology Licensing, UC
 * Berkeley, 2150 Shattuck Avenue, Suite 510, Berkeley, CA 94720-1620,
 * (510) 643-7201, for commercial licensing opportunities. 
 *
 * This code is derived from the Stanford/CMU enet packet filter,
 * distributed as part of 4.3BSD, and code contributed to Berkeley by
 * Steven McCanne and Van Jacobson both of Lawrence Berkeley Laboratory,
 * and Andrew Begel of the Berkeley Computer Science Division of the
 * Electrical Engineering and Computer Science Department.
 * 
 * IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 * SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 * REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE. THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
 * ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO
 * OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS.
 */

#ifndef lint
static char rcsid[] =
    "@(#) $Header: /usr/src/mash/repository/bpfl/scanner.l,v 1.2 1997/11/18 00:09:48 mccanne Exp $ (LBL)";
#endif

#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <time.h>
#include "bpf-vm.h"
#include "pcap-int.h"

extern struct bpf_insn *
bpfl_compile(int* programLen,
	     char *buf, int optimize, u_int32_t mask,
	     int retval);

u_int bpf_filter(struct bpf_insn *, u_char *, u_int, u_int, int32_t mem[BPF_MEMWORDS]);

extern int	pcap_offline_read(pcap_t *, int, pcap_handler, u_char *);

extern int
sf_next_packet(pcap_t *p, struct pcap_pkthdr *hdr, u_char *buf, int buflen);

extern pcap_t *
pcap_open_offline(const char *fname, char *errbuf);

/*
 * Copy arg vector into a new buffer, concatenating arguments with spaces.
 */
char *
copy_argv(register char **argv)
{
	register char **p;
	register int len = 0;
	char *buf;
	char *src, *dst;

	p = argv;
	if (*p == 0)
		return 0;

	while (*p)
		len += strlen(*p++) + 1;

	buf = (char *)malloc(len);
	p = argv;
	dst = buf;
	while ((src = *p++) != 0) {
		while ((*dst++ = *src++) != '\0');
		dst[-1] = ' ';
	}
	dst[-1] = '\0';

	return buf;
}

int dflag;
extern int optind;

main(int argc, char **argv)
{
	struct bpf_insn* filter;
	int filterLen;
	int optimize = 0;
	int op;
	char *cmdbuf;
	char errbuf[1024];
	pcap_t *pd;
	int status = 0, n = 0, count = 0;
	struct pcap_pkthdr h;
	int32_t mem[BPF_MEMWORDS];
	clock_t startclock;
	clock_t totalclock;

	pd = pcap_open_offline(argv[1], errbuf);
	argv++; argc--;
	
	while ((op = getopt(argc, argv, "dO")) != -1) {
	  switch (op) {
	  case 'O':
	    ++optimize;
	    break;
	    
	  case 'd':
	    ++dflag;
	    break;
	  }
	}
	cmdbuf = copy_argv(&argv[optind]);
	filter = bpfl_compile(&filterLen, cmdbuf, optimize, 0xffffff00, 128);
	if (filter == 0) {
	  printf("tester: %s\n", bpf_geterror()); //"FIX-GET-ERROR");
	  exit(1);
	}
	bpf_dump(filter, filterLen);
	startclock = clock();
	while(status == 0) {
	  status = sf_next_packet(pd, &h, pd->buffer, pd->bufsize);
	  if (!status) {
	    int result;
	    clock_t current;
	    current = clock();
	    result = bpf_filter(filter, pd->buffer, h.len, h.caplen, mem);
	    if (result) { 
	      //printf("Match!\n"); 
	      count++; }
	    else { //printf("No Match.\n");
	    } 
	    totalclock += clock() - current;
	    n++;
	  }
	}
	printf("Processed %d packets. Matched on %d packets.\n", n, count);
	printf("Average filter time was %d microseconds.\n ", 
	       (int)((float)totalclock / (float)n));
	printf("Total time was %d microseconds.\n", totalclock);
	exit(0);
}


