char pcap_version[] = "0.4a6";
