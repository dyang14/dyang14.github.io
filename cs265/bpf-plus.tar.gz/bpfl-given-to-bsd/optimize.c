/* 
 * Copyright �1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996,
 * 1997, 2001, 2004. The Regents of the University of California 
 * (Regents). All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research, and not-for-profit purposes,
 * without fee and without a signed licensing agreement, is hereby
 * granted, provided that the above copyright notice, this paragraph and
 * the following three paragraphs appear in all copies, modifications, and
 * distributions. Contact The Office of Technology Licensing, UC
 * Berkeley, 2150 Shattuck Avenue, Suite 510, Berkeley, CA 94720-1620,
 * (510) 643-7201, for commercial licensing opportunities. 
 *
 * This code is derived from the Stanford/CMU enet packet filter,
 * distributed as part of 4.3BSD, and code contributed to Berkeley by
 * Steven McCanne and Van Jacobson both of Lawrence Berkeley Laboratory,
 * and Andrew Begel of the Berkeley Computer Science Division of the
 * Electrical Engineering and Computer Science Department.
 * 
 * IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 * SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 * REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE. THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
 * ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO
 * OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS.
 *
 *  Optimization module for tcpdump intermediate representation.
 */
#ifndef lint
static char rcsid[] =
    "@(#) $Header: /usr/src/mash/repository/bpfl/optimize.c,v 1.5 1997/11/20 17:39:29 mccanne Exp $ (LBL)";
#endif

#ifdef OPT_DEBUG
#include <stdio.h>
#endif
#include <sys/types.h>
#include <sys/time.h>

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

#include "bpf-vm.h"
#include "gencode.h"
#include "value_numbering.h"

#define NOP -1

static void
opt_block_dump(struct block *root);


extern int dflag;

/*
 * XXX: Add a comment here that explains the theory of operation.
 * Level numbers...
 * pseudo-registers and scratch memory conventions
 * 
 */

/*
 * A flag to indicate that further optimization is needed.
 * Iterative passes are continued until a given pass yields no
 * branch movement.
 */
static int done;

/*
 * A block is marked if only if its mark equals the current mark.
 * Rather than traverse the code array, marking each item, 'cur_mark' is
 * incremented.  This automatically makes each element unmarked.
 */
static int cur_mark;
#define isMarked(p) ((p)->mark == cur_mark)
#define unMarkAll() cur_mark += 1
#define Mark(p) ((p)->mark = cur_mark)

static int n_blocks;
struct block **blocks;
static int n_edges;
struct edge **edges;

/*
 * A bit vector set representation of the dominators.
 * We round up the set size to the next power of two.
 */
static int nodewords;
static int edgewords;
static int defusewords;

u_long *space;

static uset all_dom_sets;
static uset all_closure_sets;
static uset all_edge_sets;
static uset all_defuse_sets;

int set_nullp(uset a, int n) {
  register u_long *_x = a;
  register int _n = n, output = 0;
  while (--_n >= 0) output |= *_x;
  return !output;
}


// Clever, huh?
int bit_count(u_long i)
{
      i = ((i & 0xAAAAAAAAL) >>  1) + (i & 0x55555555L);
      i = ((i & 0xCCCCCCCCL) >>  2) + (i & 0x33333333L);
      i = ((i & 0xF0F0F0F0L) >>  4) + (i & 0x0F0F0F0FL);
      i = ((i & 0xFF00FF00L) >>  8) + (i & 0x00FF00FFL);
      i = ((i & 0xFFFF0000L) >> 16) + (i & 0x0000FFFFL);
      return (int)i;
}

int set_count(uset a, int n) {
  register u_long *_a = (a);
  register int _b = (n), output = 0, _i;
  while (--_b >= 0) {
    output += bit_count(*_a++);
  }
  return output;
}

int set_ffs(uset a, int n) {
  register int _n = n, i, j;
  for(j = 0; j < _n; j++) {
    for (i = 0; i < BITS_PER_WORD; i++) {
      if (SET_MEMBER(a, j*BITS_PER_WORD + i))
	return j*BITS_PER_WORD + i;
    }
  }
  return 0;
}

#ifndef MAX
#define MAX(a,b) ((a)>(b)?(a):(b))
#endif

/*
 * Find dominator relationships.
 * Assumes graph has been leveled.
 * Lists all nodes that dominate you. 
 */
static void
find_dom(struct block *root) {
  int i,j;
  u_long *x;
  
  /*
   * Initialize sets to contain all nodes.
   */
  
  for(i = 0; i< n_blocks; ++i) {
    struct block *b = blocks[i];
    for(j = nodewords; --j >=0;)
      blocks[i]->dom[j] = ~0;
  }
  //x = all_dom_sets;
  //i = n_blocks * nodewords;
  //while (--i >= 0)
  //  *x++ = ~0;
  /* Root starts off empty. */
  for (i = nodewords; --i >= 0;)
    root->dom[i] = 0;
  
  /* root->level is the highest level no found. */
  for (i = 0; i < n_blocks; ++i) {
    struct block *b = blocks[i];
    //    printf("computing dominators for block %d\n", b->id);
    //printf("dominator is %x\n", *b->dom);
    SET_INSERT(b->dom, b->id);
    //printf("dominator is now %x\n", *b->dom);
    if (JT(b) != 0) {
      SET_INTERSECT(JT(b)->dom, b->dom, nodewords);
      //printf("dominator of %d is %x\n", JT(b)->id, *JT(b)->dom);
    }
    if (JF(b) != 0) {
      SET_INTERSECT(JF(b)->dom, b->dom, nodewords);
      //printf("dominator of %d is %x\n", JF(b)->id, *JF(b)->dom);
    }
  }
}

static void
propedom(struct edge *ep)
{
	SET_INSERT(ep->edom, ep->id);
	if (ep->succ) {
		SET_INTERSECT(ep->succ->et.edom, ep->edom, edgewords);
		SET_INTERSECT(ep->succ->ef.edom, ep->edom, edgewords);
	}
}

/*
 * Compute edge dominators.
 * Assumes graph has been leveled and predecessors established.
 */
static void
find_edom(struct block *root)
{
	int i;
	uset x;

	x = all_edge_sets;
	for (i = n_edges * edgewords; --i >= 0; )
		x[i] = ~0;

	/* root->level is the highest level no found. */
	memset(root->et.edom, 0, edgewords * sizeof(*(uset)0));
	memset(root->ef.edom, 0, edgewords * sizeof(*(uset)0));
	for (i = 0; i < n_blocks; ++i) {
		struct block *b = blocks[i];
		propedom(&b->et);
		propedom(&b->ef);
	}
}

/*
 * Find the backwards transitive closure of the flow graph.  These sets
 * are backwards in the sense that we find the set of nodes that reach
 * a given node, not the set of nodes that can be reached by a node.
 *
 * Assumes graph has been leveled.
 */
static void
find_closure(struct block *root)
{
	int i;

	/*
	 * Initialize sets to contain no nodes.
	 */
	memset((char *)all_closure_sets, 0,
	      n_blocks * nodewords * sizeof(*all_closure_sets));

	/* root->level is the highest level no found. */
	for (i = 0; i < n_blocks; ++i) {
	  struct block *b = blocks[i];
	  
	  SET_INSERT(b->closure, b->id);
	  if (JT(b) != 0) {
	    SET_UNION(JT(b)->closure, b->closure, nodewords);
	    SET_UNION(JF(b)->closure, b->closure, nodewords);
	  }
	}
}

/*
 * Return the mask of atoms that are used by s.
 * This mask could be empty.
 */
static void
atomuse(struct stmt *s, uset u)
{
  register int c = s->code;
  
  if (c == NOP) return;
  
  switch (BPF_CLASS(c)) {
    
  case BPF_RET:
    if (c == (BPF_RET|BPF_REG))
      SET_INSERT(u, s->rd);
    return;
    
  case BPF_LD:
    if (BPF_MODE(c) == BPF_IND) 
      SET_INSERT(u, s->ra);
    return;
    
  case BPF_LDM:
    SET_INSERT(u, MEMATOM(s->imm));
    return;
    
  case BPF_STM:
    SET_INSERT(u, s->rd);
    return;
    
  case BPF_JMP:
    if (c != (BPF_JMP|BPF_JA))
      SET_INSERT(u, s->rd);
    return;
    
  case BPF_ALU:
    if (BPF_ALU_MODE(c) == BPF_REG) {
      SET_INSERT(u, s->ra);
      SET_INSERT(u, s->rb);
      return;
    }
    SET_INSERT(u, s->ra);
    return;
    
  }
  abort();
  /* NOTREACHED */
}

/*
 * Return the mask of atoms that are defined by s.
 * Return the register number that is defined by 's'.
 * (We assume that a single stmt cannot define more than one atom.)
 */
static void
atomdef(struct stmt *s, uset u)
{

  if (s->code == NOP)
    return;
  
  switch (BPF_CLASS(s->code)) {
    
  case BPF_LD:
  case BPF_LDM:
  case BPF_ALU:
    SET_INSERT(u, s->rd);
    return;

  case BPF_STM:
    SET_INSERT(u, MEMATOM(s->imm));
    return;
  }
  return;
}

static void
compute_local_ud(struct block *b)
{
	struct slist *s;
	/* we can use b->out_use as a temporary */

	for (s = b->stmts; s; s = s->next) {
	  if (s->s.code == NOP)
	    continue;
	  atomuse(&s->s, b->out_use);
	  SET_INTERSECT(b->out_use, b->def, defusewords);
	  if (set_nullp(b->out_use, defusewords)) 
	    SET_UNION(b->in_use, b->out_use, defusewords);

	  SET_SET(b->out_use, 0, defusewords);
	  atomdef(&s->s, b->out_use);
	  SET_INTERSECT(b->out_use, b->in_use, defusewords);
	  if (set_nullp(b->out_use, defusewords))
	    SET_UNION(b->kill, b->out_use, defusewords);
	  SET_UNION(b->def, b->out_use, defusewords);
	}
	if (BPF_CLASS(b->s.code) == BPF_JMP) {
	  int r = b->s.rd;
	  if (!SET_MEMBER(b->def, r)) SET_INSERT(b->in_use, r);
	}
}

static void
find_ud(struct block *root)
{
	int i;
	/*
	 * root->level is the highest level no found;
	 * count down from there.
	 */
	for (i = 0; i < n_blocks; ++i) {
	  struct block *p = blocks[i];
	  SET_SET(p->in_use, 0, defusewords);
	  SET_SET(p->out_use, 0, defusewords);
	  SET_SET(p->def, 0, defusewords);
	  SET_SET(p->kill, 0, defusewords);
	  compute_local_ud(p);
	  // out_use was used as a temporary in compute_local_ud.
	  SET_SET(p->out_use, 0, defusewords);
	}

	/*
	 * Propagate use-def sets in reverse topological order.
	 */
	for (i = n_blocks; --i >= 0; ) {
	  struct block *p = blocks[i];
	  if (JT(p)) {
	    SET_UNION(p->out_use, JT(p)->in_use, defusewords);
	    SET_UNION(p->out_use, JF(p)->in_use, defusewords);
	  }
	  SET_UNION_SUBTRACT(p->in_use, p->out_use, p->kill, defusewords); 
	}
}

// Expects valnodes to be already set up.
// run find_value_numbering() before this.
void register_allocation(struct block *root) {
  int i, j, numreg;
  // get first valnode.
  valnode *v = find_valnode(0);
  valnode *v1, *v2;
  uset temp = (u_long*)malloc(defusewords);

  numreg = get_num_reg();
  v1 = v;
  for(i = 0; i < numreg; i++) {
    v2 = v + numreg - 1;
    for(j = numreg - 1; j >= i; j--) {

      // if it's not live, skip it.
      if (v2->dest.type == DEST_UNDEFINED) { v2--; continue; }

      // if earlier register is not live, use it.
      if (v1->dest.type == DEST_UNDEFINED) {
	replace_register(j, i);
	find_valnode(i)->dest = make_dest(DEST_REG, i);
	SET_COPY(v1->interference, v2->interference, nodewords);
	SET_SET(v2->interference, 0, nodewords);
	v2--;
	continue;
      }

      SET_COPY(temp, v1->interference, nodewords);
      SET_INTERSECT(temp, v2->interference, nodewords);
      if (set_nullp(temp, nodewords)) {
	replace_register(j, i);
	SET_UNION(v1->interference, v2->interference, nodewords);
	SET_SET(v2->interference, 0, nodewords);
      }
      v2--;
    }
    v1++;
  }
  
  // Check for too many registers
  // We use r30 and r31 in the VM
  v = find_valnode(BPF_ARCHREG-2);
  for(i = BPF_ARCHREG; i < numreg; i++) {
    if (v->dest.type != DEST_UNDEFINED) 
      bpf_error("too many used registers");
    v++;
  }

#ifdef OPT_DEBUG
  if (dflag) opt_block_dump(root);
#endif
}


void liveness(struct stmt *s, struct block *b) {
  int rega, regb;
  instruction instr; 

  rega = regb = -1;

  if (s->code != NOP) {
    // find the used registers in this statement.
    instr = valnum_instruction(s);
    switch(instr.type) {
    case IT_PACKET_REG:
      rega = instr.instr.packet_reg.reg; break;
    case IT_REG_REG:
      rega = instr.instr.reg_reg.reg1;
      regb = instr.instr.reg_reg.reg2;
      break;
    case IT_REG_IMM:
      rega = instr.instr.reg_imm.reg;
      break;
    case IT_JMP:
      rega = instr.instr.jmp.reg;
      break;
    }

    // if rega is used, find its definition and take the subtraction
    // of the use's closure with the def's closure. This is where the 
    // register def is live. 
    if (rega >= 0) {
      struct block *p;
      valnode *v = find_valnode(rega);
      v->dest = make_dest(DEST_REG, rega);
      p = v->b;
      SET_UNION_SUBTRACT(v->interference, b->closure, p->closure, nodewords);
      SET_INSERT(v->interference, b->id); // you're live in your own block
    }
    if (regb >= 0) {
      struct block *p;
      valnode *v = find_valnode(regb);
      v->dest = make_dest(DEST_REG, regb);
      p = v->b;
      SET_UNION_SUBTRACT(v->interference, b->closure, p->closure, nodewords);
      SET_INSERT(v->interference, b->id); // you're live in your own block
    }
  }
}
	    

void find_value_numbering() {
  struct slist *s;
  int i;

  for (i = 0; i < get_num_reg(); i++) {
    find_valnode(i)->dest = make_dest(DEST_UNDEFINED, i);
  }

  for (i = n_blocks; --i >= 0; ) {
    struct block *b = blocks[i];
    s = b->stmts;
    while(s != NULL) {
      if (s->s.code != NOP) {
	insert_valnode(make_valnode(b, &s->s));
      }
      s = s->next;
    }
  }

  for (i = n_blocks; --i >= 0; ) {
    struct block *b = blocks[i];
    s = b->stmts;
    while(s != NULL) {
      if (s->s.code != NOP) {
	liveness(&s->s, b);
      }
      s = s->next;
    }
    if (&b->s != NULL) liveness(&b->s, b);
  }
  
}


void total_redundancy_elimination() {
  struct slist *s;
  valnode *best_valnode;
  int i;

#ifdef OPT_DEBUG
  if (dflag)
    printf("about to do total redundancy elimination\n");
#endif

  for (i = n_blocks-1; i >= 0; i--) {
    struct block *b = blocks[i];
    s = b->stmts;

    while(s != NULL) {
      if (s->s.code != NOP) {
	// any answer that comes back will be my valnode
	// or the earliest dominating valnode
	best_valnode = find_earliest(&s->s);
	if (best_valnode->b->id != i &&
	    ((BPF_CLASS(s->s.code) != BPF_STM && 
	     best_valnode->dest.place != s->s.rd) &&
	     best_valnode->dest.place != s->s.imm)) {
	  done = 0; // we modified something. we're not done.
	  s->s.code = BPF_ALU|BPF_ADD|BPF_IMM;
	  s->s.ra = best_valnode->dest.place;
	  s->s.imm = 0;
	  insert_valnode(make_valnode(b, &s->s));
	  if (BPF_CLASS(s->s.code) != BPF_STM) {
	    /* remove copies and replace uses by previous register */
#ifdef OPT_DEBUG
	    if (dflag)
	      printf("r%d = r%d and is redundant\n", s->s.rd, s->s.ra); 
#endif
	    replace_register(s->s.rd, s->s.ra);
	    s->s.code = NOP;
	  }
	}
      }
      s = s->next;
    }
  }
}

void replace_register(int reg, int replacement) {
  struct slist *s;
  struct stmt *statement;
  int i;
  instruction ins;
  destination dest;

#ifdef OPT_DEBUG
  if (dflag)
    printf("replacing r%d  with  r%d\n", reg, replacement); 
#endif
  for(i = 0; i<n_blocks; i++) {
    struct block *b = blocks[i];
    s = b->stmts;
    while (s != NULL) {
      statement = &s->s;
      ins = valnum_instruction(statement);
      switch (ins.type) {
      case IT_PACKET_REG:
	if (ins.instr.packet_reg.reg == reg) statement->ra = replacement;
	break;
      case IT_REG_REG:
	if (ins.instr.reg_reg.reg1 == reg) statement->ra = replacement;
	if (ins.instr.reg_reg.reg2 == reg) statement->rb = replacement;
	break;
      case IT_MEM:  // STM instruction
	if (ins.instr.mem.reg == reg) statement->rd = replacement;
	break;
      case IT_REG_IMM:
	if (ins.instr.reg_imm.reg == reg) statement->ra = replacement;
	break;
      }
      dest = valnum_destination(statement);
      switch (dest.type) {
      case DEST_REG:
	if (dest.place == reg) statement->rd = replacement;
	break;
      }
      s = s->next;
    }
    statement = &b->s;
    ins = valnum_instruction(statement);
    if (ins.type == IT_JMP) {
      if (statement->rd == reg) statement->rd = replacement;
    }
  }
  erase_dest(make_dest(DEST_REG, reg));
}
      
static void
fold_op(struct stmt *s, int v0, int v1)
{
	int32_t a, b;

	a = v0;
	b = v1;

	switch (BPF_OP(s->code)) {
	case BPF_ADD:
		a += b;
		break;

	case BPF_SUB:
		a -= b;
		break;

	case BPF_MUL:
		a *= b;
		break;

	case BPF_DIV:
		if (b == 0)
			bpf_error("division by zero");
		a /= b;
		break;

	case BPF_AND:
		a &= b;
		break;

	case BPF_OR:
		a |= b;
		break;

	case BPF_LSH:
		a <<= b;
		break;

	case BPF_RSH:
		a >>= b;
		break;

	case BPF_NEG:
		a = -a;
		break;

	default:
		abort();
	}
	s->imm = a;
	s->code = BPF_LD|BPF_IMM;
	done = 0;
}

static inline struct slist *
this_op(struct slist *s)
{
	while (s != 0 && s->s.code == NOP)
		s = s->next;
	return s;
}


static void
opt_peep(struct block *b)
{
	struct slist *s;
	struct slist *next, *last;
	valnode *val;

	s = b->stmts;
	if (s == 0) return;

	last = s;
	while (1) {
	  s = this_op(s);
	  if (s == 0)
	    break;
	  next = this_op(s->next);
	  if (next == 0)
	    break;
	  last = next;
	  
	  /*
	   * stm  rx,M[k]	-->	st  rx,M[k]
	   * ldm  M[k],ry		add rx,0,ry
	   */
	  if (s->s.code == BPF_STM && next->s.code == BPF_LDM &&
	      s->s.imm == next->s.imm) {
	    done = 0;
	    next->s.code = BPF_ALU|BPF_ADD|BPF_IMM;
	    next->s.imm = 0;
	    next->s.ra = s->s.rd;
	    insert_valnode(make_valnode(b, &next->s));
	  }
	  
	  s = next;
	}
	/*
	 * If we have a subtract to do a comparison, and the register
	 * is a known constant, we can merge this value into the
	 * comparison.  XXX fix this check to work for registers
	 * other than r0.
	 */
	if (last->s.code == (BPF_ALU|BPF_SUB|BPF_REG) &&
	    last->s.ra == 0 && last->s.rd == 0 &&
	    !SET_MEMBER(b->out_use, 0)) {
	  val = find_dest(make_dest(DEST_REG, last->s.rb));
	  if (val != NULL && is_constantp(val->instr)) {
	    int op;
	    
	    b->s.imm += val->instr.instr.imm.imm;
	    op = BPF_OP(b->s.code);
	    if (op == BPF_JGT || op == BPF_JGE) {
	      struct block *t = JT(b);
	      JT(b) = JF(b);
	      JF(b) = t;
	      b->s.imm += 0x80000000;
	    }
	    last->s.code = NOP;
	    done = 0;
	  } else if (BPF_CLASS(b->s.code) == BPF_JMP &&
		     BPF_JMP_MODE(b->s.code) == BPF_IMM &&
		     b->s.imm == 0) {
	  }
	}
	/*
	 * Likewise, a constant subtract can be simplified.
	 */
	else if (last->s.code == (BPF_ALU|BPF_SUB|BPF_IMM) &&
		 last->s.ra == 0 && last->s.rd == 0 &&
		 !SET_MEMBER(b->out_use, 0)) {
		int op;

		b->s.imm += last->s.imm;
		last->s.code = NOP;
		op = BPF_OP(b->s.code);
		if (op == BPF_JGT || op == BPF_JGE) {
		  struct block *t = JT(b);
		  JT(b) = JF(b);
		  JF(b) = t;
		  b->s.imm += 0x80000000;
		}
		done = 0;
	}
	/*
	 * If register is a known constant, we can compute the
	 * comparison result.
	 */
	val = find_dest(make_dest(DEST_REG, b->s.rd));
	if (val != NULL && is_constantp(val->instr) && 
	    BPF_JMP_MODE(b->s.code) == BPF_IMM) {
	  int32_t v = val->instr.instr.imm.imm;
	  switch (BPF_OP(b->s.code)) {
	    
	  case BPF_JEQ:
	    v = v == b->s.imm;
	    break;
	    
	  case BPF_JGT:
	    v = (unsigned)v > b->s.imm;
	    break;
	    
	  case BPF_JGE:
	    v = (unsigned)v >= b->s.imm;
	    break;
	    
	  default:
	    abort();
	  }
	  if (JF(b) != JT(b))
	    done = 0;
	  if (v)
	    JF(b) = JT(b);
	  else
	    JT(b) = JF(b);
	}
}

/*
 * Compute the symbolic value of expression of 's', and update
 * anything it defines in the value table 'val'.  If 'alter' is true,
 * do various optimizations.  This code would be cleaner if symbolic
 * evaluation and code transformations weren't folded together.
 */
static void
opt_stmt(struct block *b, struct stmt *s, int alter)
{
	int op;
	int ra = s->ra;
	int rb = s->rb;
	int rd = s->rd;
	valnode *v, *v1;

	switch (s->code) {

	case BPF_LD|BPF_ABS|BPF_W:
	case BPF_LD|BPF_ABS|BPF_H:
	case BPF_LD|BPF_ABS|BPF_B:
	  break;

	case BPF_LD|BPF_IND|BPF_W:
	case BPF_LD|BPF_IND|BPF_H:
	case BPF_LD|BPF_IND|BPF_B:
	  v = find_dest(make_dest(DEST_REG, ra));
	  
	  if (v != NULL) {
	    if (alter && is_constantp(v->instr)) {  
	      // If the index register is already loaded, and 
	      // it's a constant, add it to the current immediate
	      // and change LDIndex -> LDAbs
	      s->code = BPF_LD|BPF_ABS|BPF_SIZE(s->code);
	      s->imm += v->instr.instr.imm.imm;
	      insert_valnode(make_valnode(b, s));
	      done = 0;
	    }
	  }
	  break;
		  
	case BPF_LD|BPF_IMM:
	  break;
	case BPF_ALU|BPF_NEG:
	  v = find_dest(make_dest(DEST_REG, ra));
	  if (v != NULL) {
	    if (alter && is_constantp(v->instr)) {
	      s->code = BPF_LD|BPF_IMM;
	      s->imm = -(v->instr.instr.imm.imm);
	      insert_valnode(make_valnode(b, s));
	    } 
	  }
	  break;
	
	case BPF_ALU|BPF_ADD|BPF_IMM:
	case BPF_ALU|BPF_SUB|BPF_IMM:
	case BPF_ALU|BPF_MUL|BPF_IMM:
	case BPF_ALU|BPF_DIV|BPF_IMM:
	case BPF_ALU|BPF_AND|BPF_IMM:
	case BPF_ALU|BPF_OR|BPF_IMM:
	case BPF_ALU|BPF_LSH|BPF_IMM:
	case BPF_ALU|BPF_RSH|BPF_IMM:
	  op = BPF_OP(s->code);
	  if (alter) {
	    if (s->imm == 0 && s->ra == s->rd) {
	      if (op == BPF_ADD || op == BPF_SUB ||
		  op == BPF_LSH || op == BPF_RSH ||
		  op == BPF_OR) {
		s->code = NOP;
		break;
	      }
	      if (op == BPF_MUL || op == BPF_AND) {
		s->code = BPF_LD|BPF_IMM;
		insert_valnode(make_valnode(b, s));
		break;
	      }
	    }
	    v = find_dest(make_dest(DEST_REG, ra));
	    if (v != NULL && is_constantp(v->instr)) {
	      fold_op(s, v->instr.instr.imm.imm, s->imm);
	      insert_valnode(make_valnode(b, s));
	      break;
	    }
	  }
	  break;

	case BPF_ALU|BPF_ADD|BPF_REG:
	case BPF_ALU|BPF_SUB|BPF_REG:
	case BPF_ALU|BPF_MUL|BPF_REG:
	case BPF_ALU|BPF_DIV|BPF_REG:
	case BPF_ALU|BPF_AND|BPF_REG:
	case BPF_ALU|BPF_OR|BPF_REG:
	case BPF_ALU|BPF_LSH|BPF_REG:
	case BPF_ALU|BPF_RSH|BPF_REG:
	  op = BPF_OP(s->code);
	  v = find_dest(make_dest(DEST_REG, rb));
	  v1 = find_dest(make_dest(DEST_REG, ra));
	  if (alter && v != NULL && is_constantp(v->instr)) {
	    if (v1 != NULL && is_constantp(v1->instr)) {
	      fold_op(s, v->instr.instr.imm.imm, v1->instr.instr.imm.imm);
	      insert_valnode(make_valnode(b, s));
	    } else {
	      s->code = BPF_ALU|BPF_IMM|op;
	      s->imm = v->instr.instr.imm.imm;
	      done = 0;
	      insert_valnode(make_valnode(b, s));
	    }
	    break;
	  }
	  /*
	   * If ra is constant and op is commutative:
	   * 	op ra,rb,rc -> op rb,#imm,rc
	   */
	  if (alter && v1 != NULL && is_constantp(v1->instr) &&
	      (op == BPF_ADD || op == BPF_AND || op == BPF_OR)) {
	    s->code = BPF_ALU|BPF_IMM|op;
	    s->imm = v1->instr.instr.imm.imm;
	    s->ra = s->rb;
	    done = 0;
	    insert_valnode(make_valnode(b, s));
	  }
	  break;

	case BPF_LDM:
	case BPF_STM:
	  break;
	}
}

static void
deadstmt(register struct stmt *s, register struct stmt *last[], uset m) {
  
  //printf("deadstmt\n");
  atomuse(s, m);
  
  while (!set_nullp(m, defusewords)) {
    int k = set_ffs(m, defusewords);
    last[k] = NULL;
    SET_DELETE(m, k);
  }
  
  atomdef(s, m);
  while (!set_nullp(m, defusewords)) {
    int k = set_ffs(m, defusewords);
    if (last[k]) {
      done = 0;
      last[k]->code = NOP;
    }
    last[k] = s;
    SET_DELETE(m, k);
  }
  
}

/* dead stores to registers. stores to persistent memory are never dead. */
static void
opt_deadstores(register struct block *b) {
  register struct slist *s;
  register int i;
  struct stmt **last;
  uset m;

  last = (struct stmt**)malloc(sizeof(struct stmt*) * get_num_reg());
  m = (u_long *)malloc(sizeof(u_long) * defusewords);
  /*
   * last points to the latest statement that
   * defines the given atom
   */
  for (i = 0; i < get_num_reg(); ++i)
    last[i] = NULL;
  
  for (s = b->stmts; s != 0; s = s->next) {
    SET_SET(m, 0, defusewords);
    deadstmt(&s->s, last, m);
  }
  SET_SET(m, 0, defusewords);
  deadstmt(&b->s, last, m);
  
  for (i = 0; i < get_num_reg(); ++i) {
    if ((last[i] != NULL) && (!(SET_MEMBER(m, i)))) {
      SET_SET(m, 0, defusewords);
      atomuse(&b->s, m);
      if (!SET_MEMBER(m, i)) {
	last[i]->code = NOP;
	done = 0;
      }
    }
  }
  free(m);
  free(last);
}


static void
opt_blk(struct block *b, int do_stmts, struct block* root)
{
  struct slist *s;
  struct edge *p;
  int i;
  valnode *jmpval, *v;
  
  //jmpval = find_dest(make_dest(DEST_REG, b->s.rd));
  
  for (s = b->stmts; s; s = s->next)
    opt_stmt(b, &s->s, do_stmts);
  opt_peep(b);
  opt_deadstores(b);
}

  /*
   * This is a special case: if we don't use anything from this
   * block, and we load the jump's test-register with value that is
   * already there, or if this block is a return,
   * eliminate all the statements.
   */
  /* XXX BROKEN! */
  //v = find_dest(make_dest(DEST_REG, b->s.rd));
  /*	if (do_stmts && 
	((set_nullp(b->out_use, defusewords) && 
	BPF_CLASS(b->s.code) == BPF_JMP &&
	b->s.code != (BPF_JMP|BPF_JA) &&
	v != NULL && instruction_equalp(v->instr, jmpval->instr)) ||
	BPF_CLASS(b->s.code) == BPF_RET)) {
	if (b->stmts != 0) {
	b->stmts = 0;
	done = 0;
	}
	} else { */
  //	}
//}

/*
 * Return true if any register that is used on exit from 'succ', has
 * an exit value that is different from the corresponding exit value
 * from 'b'.
 */
static int
use_conflict(struct block *b, struct block *succ)
{
  int i, count, k;
  uset m;
  struct slist *s;
  
  m = (u_long *)malloc(sizeof(u_long) * defusewords);
  SET_SET(m, 0, defusewords);

  // forall defs in this block, are they used outside this block?
  for (s = b->stmts; s; s = s->next) {
    if (s->s.code == NOP)
      continue;
    atomdef(&s->s, m);
  }
  
  for (i = 0; i < defusewords; ++i) {
    register u_long x = m[i];
    
    while (x != 0) {
      k = ffs(x) - 1; // find the first 1.
      x &=~ (1 << k); // subtract it from the def set.
      k += i * BITS_PER_WORD; // move k to the real correct bit.
      //printf("register %d is used in block #%d", k, b->id);
      count = set_count(find_valnode(k)->interference, nodewords);
      //printf(" %d times (interference = %d)\n", count, 
      //	     find_valnode(k)->interference[0]);
      if (count > 1) return 1; // it's used outside the defining block
    }
  }
  return 0;
}

static struct block *
fold_edge(struct block *child, struct edge *ep)
{
	int sense;
	struct block *parent = ep->pred;
	int code = parent->s.code;

	// is this edge dominator a true or false branch?
	sense = (ep == &parent->et) ? 1 : 0;

	// check out the control flow instruction at the end of the blocks.
	// if it's not the same, quit.
	// if it's not a jump, quit.
	if (code != child->s.code || BPF_CLASS(code) != BPF_JMP)
		return (0);

	// look at the instruction that defines the branch register
	if (!instruction_equalp(find_valnode(child->s.rd)->instr, 
				find_valnode(parent->s.rd)->instr)) 
	  
		/*
		 * The two blocks compare different values.
		 * We can't tell anything.
		 */
	  return 0;

	// if the jump-comparison immediate is the same, then we have a match
	if (child->s.imm == parent->s.imm)
	  /*
	   * The operands are identical, so the
	   * result is true if a true branch was
	   * taken to get here, otherwise false.
	   */
	  return (sense ? JT(child) : JF(child));
	
	// the immediates are different. If the sense is true, then 
	// we know the answer is really false.
	if (sense && code == (BPF_JMP|BPF_JEQ|BPF_IMM)) {
	  /*
	   * At this point, we only know the comparison if we
	   * came down the true branch, and it was an equality	   * comparison with a constant.  We rely on the fact that
	   * distinct constants have distinct value numbers.
	   */
	  return (JF(child));
	}

	// we can expand this logic to cover <, >, <= and >=. 
	// we should be storing this info in a table or something.
	return (0);
}

static void
opt_j(struct edge *ep)
{
	register int i, k;
	register struct block *target;

	/* If there is no successor block, just quit. */
	if (JT(ep->succ) == 0) 
		return;

	if (JT(ep->succ) == JF(ep->succ)) {
	  /*
	   * Common branch targets can be eliminated, provided
	   * there is no data dependency.
	   */
	  // XXX If there is a conflict, we should copy the grandson block
	  // and merge it with the son.
	  if (!use_conflict(ep->pred, ep->succ->et.succ)) {
	    done = 0;
	    ep->succ = JT(ep->succ);
	  }
	}
	/*
	 * For each edge dominator that matches the successor of this
	 * edge, promote the edge successor to the its grandchild.
	 *
	 * XXX We violate the set abstraction here in favor a reasonably
	 * efficient loop.
	 */
 top:
	for (i = 0; i < edgewords; ++i) {
	  register u_long x = ep->edom[i];
	  
	  while (x != 0) {
	    k = ffs(x) - 1; // find the first 1.
	    x &=~ (1 << k); // subtract it from the dominator set.
	    k += i * BITS_PER_WORD; // move k to the real correct bit.
	    
	    target = fold_edge(ep->succ, edges[k]);
	    /*
	     * Check that there is no data dependency between
	     * nodes that will be violated if we move the edge.
	     */
	    if (target == 0) continue;
	    if (!use_conflict(ep->succ, target)) {
#ifdef OPT_DEBUG
	      if (dflag)
		printf("E [%d] %d -> %d\n",
		       ep->pred->id,
		       ep->succ->id,
		       target->id);
#endif		
	      done = 0;
	      ep->succ = target;
	      if (JT(target) != 0)
		/*
		 * Start over unless we hit a leaf.
		 */
		goto top;
	      return;
	    }
	  }
	}
}


static void
or_pullup(struct block *b, struct block *root)
{
	int at_top, compare_reg;
	struct block *pull;
	struct block **diffp, **samep;
	struct edge *ep;
	valnode *v, v2;
	instruction inst, inst2;
	char *text;

	//printf("Or Pullup: Block #%d\n", b->id);
	ep = b->in_edges;
	if (ep == 0)
		return;

	/*
	 * Make sure each predecessor loads the same value.
	 * XXX why?
	 * XXX generalize beyond r0...
	 */
	//printf("Checking for Jump\n");
	if (BPF_CLASS(b->s.code) != BPF_JMP) return;
	inst = find_valnode(b->s.rd)->instr;
	//printf("it's a jump, what's the instruction?\n");
	//text = opt_image(b, &b->s);
	//if (text != NULL) printf("%s\n", text);
	//for (ep = ep->next; ep != 0; ep = ep->next) 
	//	if (val != ep->pred->val[0])
	//		return;

	if (JT(b->in_edges->pred) == b)
		diffp = &JT(b->in_edges->pred);
	else
		diffp = &JF(b->in_edges->pred);

	at_top = 1;
	while (1) {
	  if (*diffp == 0)
	    return;
	  //	printf("Diffp is block #%d\n", (*diffp)->id);
	  //printf("JT diffp == JT(b)?\n");
		if (JT(*diffp) != JT(b))
			return;
		//printf("yes\n");
		//printf("b %d dominates diffp %d?\n", b->id, (*diffp)->id);
		if (!SET_MEMBER((*diffp)->dom, b->id))
			return;
		//printf("yes\n");
		//printf("same value?\n");
		if (BPF_CLASS((*diffp)->s.code) == BPF_JMP) {
		  inst2 = find_valnode((*diffp)->s.rd)->instr;
		  //text = opt_image((*diffp), &((*diffp)->s));
		  //if (text != NULL) printf("%s\n", text);

		  if (!(instruction_equalp(inst2, inst))) {
		    //printf("no, not the same\n"); 
		    break; 
		  }
		  //printf("yes, it's the same\n");
		}
		//printf("go down the false path\n");
		diffp = &JF(*diffp);
		at_top = 0;
	}
	samep = &JF(*diffp);
	while (1) {
		if (*samep == 0)
			return;
		//printf("samep is block #%d\n", (*samep)->id);
		//printf("JT samep == JT(b)?\n");		
		if (JT(*samep) != JT(b))
			return;

		//printf("yes\n");
		//printf("b %d dominates samep %d?\n", b->id, (*samep)->id);
		if (!SET_MEMBER((*samep)->dom, b->id))
			return;

		//printf("yes\n");
		//printf("same value?\n");
		if (BPF_CLASS((*samep)->s.code) == BPF_JMP) {
		  inst2 = find_valnode((*samep)->s.rd)->instr;
		  //text = opt_image((*samep), &((*samep)->s));
		  //if (text != NULL) printf("%s\n", text);

		  if (instruction_equalp(inst2, inst)) {
		    //printf("yes, it's the same!\n");
		    break;
		  }
		  //printf("no, it's not\n");
		}

		/* XXX Need to check that there are no data dependencies
		   between dp0 and dp1.  Currently, the code generator
		   will not produce such dependencies. */ 
		//printf("go down the false path\n");
		samep = &JF(*samep);
	}
	/* Pull up the node. */ 
	//printf("do the pullup\n");
	pull = *samep;
	*samep = JF(pull);
	JF(pull) = *diffp;

	/*
	 * At the top of the chain, each predecessor needs to point at the
	 * pulled up node.  Inside the chain, there is only one predecessor
	 * to worry about.
	 */
	if (at_top) {
	  for (ep = b->in_edges; ep != 0; ep = ep->next) {
	    if (JT(ep->pred) == b)
	      JT(ep->pred) = pull;
	    else
	      JF(ep->pred) = pull;
	  }
	}
	else
	  *diffp = pull;
	
	done = 0;
}

static void
and_pullup(struct block *b, struct block *root)
{
	int at_top, compare_reg;
	struct block *pull;
	struct block **diffp, **samep;
	struct edge *ep;
	valnode *v, v2;
	instruction inst, inst2;
	char *text;

	//printf("Or Pullup: Block #%d\n", b->id);
	ep = b->in_edges;
	if (ep == 0)
		return;

	/*
	 * Make sure each predecessor loads the same value.
	 * XXX why?
	 * XXX generalize beyond r0...
	 */
	//printf("Checking for Jump\n");
	if (BPF_CLASS(b->s.code) != BPF_JMP) return;
	inst = find_valnode(b->s.rd)->instr;
	//printf("it's a jump, what's the instruction?\n");
	//text = opt_image(b, &b->s);
	//if (text != NULL) printf("%s\n", text);
	//for (ep = ep->next; ep != 0; ep = ep->next) 
	//	if (val != ep->pred->val[0])
	//		return;

	if (JT(b->in_edges->pred) == b)
		diffp = &JT(b->in_edges->pred);
	else
		diffp = &JF(b->in_edges->pred);

	at_top = 1;
	while (1) {
	  if (*diffp == 0)
	    return;
	  //	printf("Diffp is block #%d\n", (*diffp)->id);
	  //printf("JT diffp == JT(b)?\n");
		if (JF(*diffp) != JF(b))
			return;
		//printf("yes\n");
		//printf("b %d dominates diffp %d?\n", b->id, (*diffp)->id);
		if (!SET_MEMBER((*diffp)->dom, b->id))
			return;
		//printf("yes\n");
		//printf("same value?\n");
		if (BPF_CLASS((*diffp)->s.code) == BPF_JMP) {
		  inst2 = find_valnode((*diffp)->s.rd)->instr;
		  //text = opt_image((*diffp), &((*diffp)->s));
		  //if (text != NULL) printf("%s\n", text);

		  if (!(instruction_equalp(inst2, inst))) {
		    //printf("no, not the same\n"); 
		    break; 
		  }
		  //printf("yes, it's the same\n");
		}
		//printf("go down the false path\n");
		diffp = &JT(*diffp);
		at_top = 0;
	}
	samep = &JT(*diffp);
	while (1) {
		if (*samep == 0)
			return;
		//printf("samep is block #%d\n", (*samep)->id);
		//printf("JT samep == JT(b)?\n");		
		if (JF(*samep) != JF(b))
			return;

		//printf("yes\n");
		//printf("b %d dominates samep %d?\n", b->id, (*samep)->id);
		if (!SET_MEMBER((*samep)->dom, b->id))
			return;

		//printf("yes\n");
		//printf("same value?\n");
		if (BPF_CLASS((*samep)->s.code) == BPF_JMP) {
		  inst2 = find_valnode((*samep)->s.rd)->instr;
		  //text = opt_image((*samep), &((*samep)->s));
		  //if (text != NULL) printf("%s\n", text);

		  if (instruction_equalp(inst2, inst)) {
		    //printf("yes, it's the same!\n");
		    break;
		  }
		  //printf("no, it's not\n");
		}

		/* XXX Need to check that there are no data dependencies
		   between dp0 and dp1.  Currently, the code generator
		   will not produce such dependencies. */ 
		//printf("go down the false path\n");
		samep = &JT(*samep);
	}
	/* Pull up the node. */ 
	//printf("do the pullup\n");
	pull = *samep;
	*samep = JT(pull);
	JT(pull) = *diffp;

	/*
	 * At the top of the chain, each predecessor needs to point at the
	 * pulled up node.  Inside the chain, there is only one predecessor
	 * to worry about.
	 */
	if (at_top) {
	  for (ep = b->in_edges; ep != 0; ep = ep->next) {
	    if (JT(ep->pred) == b)
	      JT(ep->pred) = pull;
	    else
	      JF(ep->pred) = pull;
	  }
	}
	else
	  *diffp = pull;
	
	done = 0;
}

/*
static void
and_pullup(struct block *b)
{
	int val, at_top;
	struct block *pull;
	struct block **diffp, **samep;
	struct edge *ep;

	ep = b->in_edges;
	if (ep == 0)
		return;

	/*
	 * Make sure each predecessor loads the same value.

	val = ep->pred->val[0];
	for (ep = ep->next; ep != 0; ep = ep->next)
		if (val != ep->pred->val[0])
			return;

	if (JT(b->in_edges->pred) == b)
		diffp = &JT(b->in_edges->pred);
	else
		diffp = &JF(b->in_edges->pred);

	at_top = 1;
	while (1) {
		if (*diffp == 0)
			return;

		if (JF(*diffp) != JF(b))
			return;

		if (!SET_MEMBER((*diffp)->dom, b->id))
			return;

		if ((*diffp)->val[0] != val)
			break;

		diffp = &JT(*diffp);
		at_top = 0;
	}
	samep = &JT(*diffp);
	while (1) {
		if (*samep == 0)
			return;

		if (JF(*samep) != JF(b))
			return;

		if (!SET_MEMBER((*samep)->dom, b->id))
			return;

		if ((*samep)->val[0] == val)
			break;

		/* XXX Need to check that there are no data dependencies
		   between diffp and samep.  Currently, the code generator
		   will not produce such dependencies. 
		samep = &JT(*samep);
	}
	/* Pull up the node. 
	pull = *samep;
	*samep = JT(pull);
	JT(pull) = *diffp;

	/*
	 * At the top of the chain, each predecessor needs to point at the
	 * pulled up node.  Inside the chain, there is only one predecessor
	 * to worry about.
	 
	if (at_top) {
		for (ep = b->in_edges; ep != 0; ep = ep->next) {
			if (JT(ep->pred) == b)
				JT(ep->pred) = pull;
			else
				JF(ep->pred) = pull;
		}
	}
	else
		*diffp = pull;

	done = 0;
}
	*/

static void opt_blks(struct block *root, int do_stmts) {
  int i;
  
#ifdef OPT_DEBUG
if (dflag)
  printf("about to do block optimizations\n");
#endif
  for (i = 0; i < n_blocks; ++i)
    opt_blk(blocks[i], do_stmts, root);
  
  if (do_stmts)
    /*
     * No point trying to move branches; it can't possibly
     * make a difference at this point.
     */
    return;
  
  /*
   * Do jump optimizations in reverse topological order
   * (to reduce the number of passes)
   */
  find_value_numbering(); // recompute this information.
#ifdef OPT_DEBUG
  if (dflag)
    opt_block_dump(root);
#endif
  for (i = n_blocks; --i >= 0; ) {
    struct block *p = blocks[i];
    if (JT(p)) {
      opt_j(&p->et);
      opt_j(&p->ef);
    }
  }
#ifdef OPT_DEBUG
  if (dflag)
    opt_block_dump(root);
#endif
  topsort(root);
  find_dom(root);
  for (i = n_blocks; --i >= 0; ) {
    struct block *p = blocks[i];
    if (JT(p)) {
      or_pullup(p, root);
      and_pullup(p, root);
    }
  }
}

static inline void
link_inedge(struct edge *parent, struct block *child)
{
	parent->next = child->in_edges;
	child->in_edges = parent;
}

static void
find_inedges(struct block *root)
{
	int i;

	for (i = 0; i < n_blocks; ++i)
		blocks[i]->in_edges = 0;

	/*
	 * Traverse the graph, adding each edge to the predecessor
	 * list of its successors.  Skip the leaves (i.e. level 0).
	 */
	for (i = 0; i < n_blocks; ++i) {
		struct block *b = blocks[i];
		if (JT(b)) {
			link_inedge(&b->et, JT(b));
			link_inedge(&b->ef, JF(b));
		}
	}
}

static void
opt_root(struct block **b)
{
	struct slist *tmp, *s;

	s = (*b)->stmts;
	(*b)->stmts = 0;
	while (BPF_CLASS((*b)->s.code) == BPF_JMP && JT(*b) == JF(*b))
		*b = JT(*b);

	tmp = (*b)->stmts;
	if (tmp != 0)
		sappend(s, tmp);
	(*b)->stmts = s;

	/*
	 * If the root node is a return, then there is no
	 * point executing any statements (since the bpf machine
	 * has no side effects).
	 */
	if (BPF_CLASS((*b)->s.code) == BPF_RET)
		(*b)->stmts = 0;
}

static void
make_marks(struct block *p)
{
	if (!isMarked(p)) {
		Mark(p);
		if (BPF_CLASS(p->s.code) != BPF_RET) {
			make_marks(JT(p));
			make_marks(JF(p));
		}
	}
}

/*
 * Mark code array such that isMarked(i) is true
 * only for nodes that are alive.
 */
static void
mark_code(struct block *p)
{
	cur_mark += 1;
	make_marks(p);
}

/*
 * True iff the two stmt lists load the same value from the packet into
 * the accumulator.
 */
static int
eq_slist(struct slist *x, struct slist *y)
{
	while (1) {
		while (x && x->s.code == NOP)
			x = x->next;
		while (y && y->s.code == NOP)
			y = y->next;
		if (x == 0)
			return y == 0;
		if (y == 0)
			return x == 0;
		if (x->s.code != y->s.code || x->s.imm != y->s.imm ||
		    /*XXX*/
		    x->s.ra != y->s.ra ||
		    x->s.rb != y->s.rb || 
		    x->s.rd != y->s.rd)
			return 0;
		x = x->next;
		y = y->next;
	}
}

static inline int
eq_blk(struct block *b0, struct block *b1)
{
  if (b0->s.code == b1->s.code &&
      b0->s.rd == b1->s.rd &&
      b0->s.imm == b1->s.imm &&
      b0->et.succ == b1->et.succ &&
      b0->ef.succ == b1->ef.succ)
    return eq_slist(b0->stmts, b1->stmts);
  return 0;
}

static void
intern_blocks(struct block *root)
{
	struct block *p;
	int i, j;
	int done;
 top:
	done = 1;
	for (i = 0; i < n_blocks; ++i)
		blocks[i]->link = 0;

	mark_code(root);

	for (i = n_blocks - 1; --i >= 0; ) {
		if (!isMarked(blocks[i]))
			continue;
		for (j = i + 1; j < n_blocks; ++j) {
			if (!isMarked(blocks[j]))
				continue;
			if (eq_blk(blocks[i], blocks[j])) {
				blocks[i]->link = blocks[j]->link ?
					blocks[j]->link : blocks[j];
				break;
			}
		}
	}
	for (i = 0; i < n_blocks; ++i) {
		p = blocks[i];
		if (JT(p) == 0)
			continue;
		if (JT(p)->link) {
			done = 0;
			JT(p) = JT(p)->link;
		}
		if (JF(p)->link) {
			done = 0;
			JF(p) = JF(p)->link;
		}
	}
	if (!done)
		goto top;
}

static void
opt_cleanup(void)
{
	free((void *)edges);
	free((void *)space);
	free((void *)blocks);
}

/*
 * Return the number of stmts in 's'.
 */
static int
slength(struct slist *s)
{
	int n = 0;

	for (; s; s = s->next)
		if (s->s.code != NOP)
			++n;
	return n;
}

/*
 * Return the number of nodes reachable by 'p'.
 * All nodes should be initially unmarked.
 */
static int
count_blocks(struct block *p)
{
	if (p == 0 || isMarked(p))
		return 0;
	Mark(p);
	return (count_blocks(JT(p)) + count_blocks(JF(p)) + 1);
}

/*
 * Do a topological sort on the blocks, entering them in the
 * blocks array.
 */
static void
topsort_r(struct block *p)
{
	int n;

	if (p == 0 || isMarked(p))
		return;

	Mark(p);
	topsort_r(JT(p));
	topsort_r(JF(p));

	n = --n_blocks;
	if (n < 0)
		abort();
	blocks[n] = p;
}

static void
topsort(struct block *p)
{
	int n;

	unMarkAll();
	n = count_blocks(p);
	n_blocks = n;
	unMarkAll();
	topsort_r(p);
	n_blocks = n;
	//printf("topsort finds %d blocks.\n", n);
}

/*
 * Allocate memory.  All allocation is done before optimization
 * is begun.  A linear bound on the size of all data structures is computed
 * from the total number of blocks and/or statements.
 */
static void
opt_init(struct block *root)
{
	u_long *p;
	int i, n, max_stmts;

	/*
	 * First, count the blocks, so we can malloc an array to map
	 * block number to block.  Then, put the blocks into the array.
	 */
	unMarkAll();
	n_blocks = n = count_blocks(root);
	blocks = (struct block **)malloc(n * sizeof(*blocks));
	topsort(root);
	/*
	 * assign a unique id to each block
	 */
	for (i = 0; i < n; ++i) blocks[i]->id = i;

	n_edges = 2 * n_blocks;
	edges = (struct edge **)malloc(n_edges * sizeof(*edges));

	edgewords = n_edges / (8 * sizeof(u_long)) + 1;
	nodewords = n_blocks / (8 * sizeof(u_long)) + 1;
	defusewords = (get_num_reg() + get_num_mem()) / (8 * sizeof(u_long)) + 1;
	init_val(nodewords);

	/* XXX */
	space = (u_long *)malloc(2 * n_blocks * nodewords * sizeof(*space)
				 + n_edges * edgewords * sizeof(*space)
				 + 5 * n_blocks * defusewords * sizeof(*space));
	p = space;
	all_dom_sets = p;
	for (i = 0; i < n; ++i) {
		blocks[i]->dom = p;
		p += nodewords;
	}
	all_closure_sets = p;
	for (i = 0; i < n; ++i) {
		blocks[i]->closure = p;
		p += nodewords;
	}
	all_edge_sets = p;
	for (i = 0; i < n; ++i) {
		register struct block *b = blocks[i];

		b->et.edom = p;
		p += edgewords;
		b->ef.edom = p;
		p += edgewords;
		b->et.id = i;
		edges[i] = &b->et;
		b->ef.id = n_blocks + i;
		edges[n_blocks + i] = &b->ef;
		b->et.pred = b;
		b->ef.pred = b;
	}
	all_defuse_sets = p;
	for(i = 0; i < n; ++i) {
	  register struct block *b = blocks[i];
	  b->in_use = p;
	  p += defusewords;
	  b->out_use = p;
	  p += defusewords;
	  b->def = p;
	  p += defusewords;
	  b->kill = p;
	  p += defusewords;
	}

}

#ifdef OPT_DEBUG
int bids[1000];
#endif

/*
 * Convert flowgraph intermediate representation to the
 * BPF array representation.  Set *lenp to the number of instructions.
 */
struct bpf_insn *
icode_to_fcode(root, lenp)
	struct block *root;
	int *lenp;
{
	int n, i, ns;
	struct bpf_insn *fp;
	struct bpf_insn *dst;
	/*XXX*/
	struct block **save = blocks;

	unMarkAll();
	n = count_blocks(root);
	blocks = (struct block **)malloc(n * sizeof(*blocks));
	topsort(root);

	ns = 0;
	for (i = 0; i < n; ++i) {
		struct block *p = blocks[i];
		p->offset = ns;
		ns += slength(blocks[i]->stmts) + 1;
		if (!(i == n - 1 || BPF_CLASS(p->s.code) == BPF_RET ||
		      JT(p) == blocks[i + 1] ||
		      JF(p) == blocks[i + 1]))
			/* need an extra ja */
			ns += 1;
	}

	fp = (struct bpf_insn *)malloc(sizeof(*fp) * ns);
	memset((char *)fp, 0, sizeof(*fp) * ns);

	dst = fp;
	for (i = 0; i < n; ++i) {
		struct slist *s;
		struct block *p = blocks[i];
		int slen = 0;
		int op0;

#ifdef OPT_DEBUG
		bids[p->offset] = p->id + 1;
#endif

		for (s = p->stmts; s != 0; s = s->next) {
			if (s->s.code == NOP)
				continue;
			dst->op0 = s->s.code << 24 |
				BPF_SET_RD(s->s.rd) |
				BPF_SET_RA(s->s.ra) |
				BPF_SET_RB(s->s.rb);
			dst->op1 = s->s.imm;
			// Debugging info. 5 bits isn't enough.
			//dst->ra = s->s.ra;
			//dst->rb = s->s.rb;
			//dst->rd = s->s.rd;
			++dst;
			++slen;
		}
	       	if (BPF_CLASS(p->s.code) == BPF_JMP) {
		  op0 = p->s.code << 24 | BPF_SET_RD(p->s.rd) | 
		    BPF_SET_RA(p->s.ra);
		}
		else {
		  op0 = p->s.code << 24 | BPF_SET_RD(p->s.rd);
		}
		//dst->rd = p->s.rd;
		dst->op1 = p->s.imm;
		/*XXX check for jumps too far */
		if (JT(p) && BPF_CLASS(p->s.code) != BPF_RET) {
		  int toff = JT(p)->offset - (p->offset + slen) - 1;
		  int foff = JF(p)->offset - (p->offset + slen) - 1;
		  if (toff < 0 || foff < 0)
		    abort();
		  if (foff == 0) {
		    op0 |= BPF_SET_OFF(toff);
		  } else if (toff == 0) {
		    /*XXX reverse conditional */
		    op0 ^= 0x80 << 24; /*XXX*/
		    op0 |= BPF_SET_OFF(foff);
		  } else {
		    op0 |= BPF_SET_OFF(toff);
		    dst->op0 = op0;
		    ++dst;
		    op0 = (BPF_JMP|BPF_JA) << 24;
		    dst->op1 = foff-1; // I think it's one too far.
		  }
		}
		dst->op0 = op0;
		++dst;
	}
	free(blocks);
	blocks = save;

#ifdef notyet
	if (ns != dst - fp)
		abort();
#endif
	*lenp = ns;

	return (fp);
}

#ifdef OPT_DEBUG
char *opt_image(struct block *b, struct stmt *s) {
  u_int code, ra, rb, rd, imm;
  int a0, a1, a2, a3;
  char *fmt, *op;
  static char image[256];/*XXX non re-entrant*/
  char operand[64];
  
  a3 = -1;

  ra = s->ra;
  rb = s->rb;
  rd = s->rd;
  imm = s->imm;
  code = s->code;

  if (s->code == NOP) return NULL;

  switch (BPF_CLASS(code)) {
  case BPF_ALU:
    if (BPF_ALU_MODE(code) == BPF_IMM) {
      fmt = "r%d, 0x%x, r%d";
      a0 = ra;
      a1 = imm;
      a2 = rd;
    } else {
      fmt = "r%d, r%d, r%d";
      a0 = ra;
      a1 = rb;
      a2 = rd;
    }
    break;
    
  case BPF_LD:
    if (BPF_MODE(code) == BPF_ABS) {
      fmt = "[%d], r%d";
      a0 = imm;
      a1 = rd;
    } else {
      fmt = "[r%d + %d], r%d";
      a0 = ra;
      a1 = imm;
      a2 = rd;
    }
    break;

  case BPF_JMP:
    if (BPF_ALU_MODE(code) ==  BPF_IMM) {
      fmt = "r%d, 0x%x, True: %d, False: %d";
      a0 = rd;
      a1 = imm;
      a2 = JT(b)->id; //n + BPF_OFF(op0) + 1; // foooooooooooooooo
      a3 = JF(b)->id;
    }
    else {
      fmt = "r%d, r%d, True: %d, False: %d";
      a0 = rd;
      a1 = ra;
      a2 = JT(b)->id; //n + BPF_OFF(op0) + 1;
      a3 = JF(b)->id;
    }
    break;
  }
  switch (code) {
    
    //	default:
    //	op = "unimp";
    //	fmt = "0x%x";
    //	a0 = code;
    //	break;
    
  case BPF_RET|BPF_IMM:
    op = "ret";
    fmt = "%d";
    a0 = imm;
    break;

  case BPF_RET|BPF_REG:
    op = "ret";
    fmt = "r%d";
    a0 = rd;
    break;
    
  case BPF_LD|BPF_W|BPF_ABS:
    op = "lw";
    break;
    
  case BPF_LD|BPF_H|BPF_ABS:
    op = "lh";
    break;
    
  case BPF_LD|BPF_B|BPF_ABS:
    op = "lb";
    break;
    
  case BPF_LD|BPF_W|BPF_IND:
    op = "lwx";
    break;
    
  case BPF_LD|BPF_H|BPF_IND:
    op = "lhx";
    break;
    
  case BPF_LD|BPF_B|BPF_IND:
    op = "lbx";
    break;
    
  case BPF_LD|BPF_IMM:
    op = "li	";
    fmt = "0x%x, r%d";
    a0 = imm;
    a1 = rd;
    break;
    
  case BPF_LDM:
    op = "lwm";
    fmt = "M[%d], r%d";
    a0 = imm;
    a1 = rd;
    break;
    
  case BPF_STM:
    op = "stm";
    fmt = "r%d, M[%d]";
    a0 = rd;
    a1 = imm;
    break;

  case BPF_JMP|BPF_JA:
    op = "ja";
    fmt = "L%d";
    a0 = imm;
    break;

  case BPF_JMP|BPF_JGT|BPF_REG:
  case BPF_JMP|BPF_JGT|BPF_IMM:
    op = "jgt";
    break;
    
  case BPF_JMP|BPF_JGE|BPF_REG:
  case BPF_JMP|BPF_JGE|BPF_IMM:
    op = "jge";
    break;
    
  case BPF_JMP|BPF_JEQ|BPF_REG:
  case BPF_JMP|BPF_JEQ|BPF_IMM:
    op = "jeq";
    break;
    
  case BPF_JMP|BPF_JLT|BPF_REG:
  case BPF_JMP|BPF_JLT|BPF_IMM:
    op = "jlt";
    break;
    
  case BPF_JMP|BPF_JLE|BPF_REG:
  case BPF_JMP|BPF_JLE|BPF_IMM:
    op = "jle";
    break;

  case BPF_JMP|BPF_JNE|BPF_REG:
  case BPF_JMP|BPF_JNE|BPF_IMM:
    op = "jne";
    break;
    
  case BPF_ALU|BPF_ADD|BPF_REG:
  case BPF_ALU|BPF_ADD|BPF_IMM:
    op = "add";
    break;
    
  case BPF_ALU|BPF_SUB|BPF_REG:
  case BPF_ALU|BPF_SUB|BPF_IMM:
    op = "sub";
    break;
    
  case BPF_ALU|BPF_MUL|BPF_REG:
  case BPF_ALU|BPF_MUL|BPF_IMM:
    op = "mul";
    break;
    
  case BPF_ALU|BPF_DIV|BPF_REG:
  case BPF_ALU|BPF_DIV|BPF_IMM:
    op = "div";
    break;
    
  case BPF_ALU|BPF_AND|BPF_REG:
  case BPF_ALU|BPF_AND|BPF_IMM:
    op = "and";
    break;
    
  case BPF_ALU|BPF_OR|BPF_REG:
  case BPF_ALU|BPF_OR|BPF_IMM:
    op = "or";
    break;
    
  case BPF_ALU|BPF_LSH|BPF_REG:
  case BPF_ALU|BPF_LSH|BPF_IMM:
    op = "lsh";
    break;
    
  case BPF_ALU|BPF_RSH|BPF_REG:
  case BPF_ALU|BPF_RSH|BPF_IMM:
    op = "rsh";
    break;
  }
  
  if (a3 < 0) (void)sprintf(operand, fmt, a0, a1, a2);
  else (void)sprintf(operand, fmt, a0, a1, a2, a3);
  (void)sprintf(image, "\t%-8s %s", op, operand);
  return (image);
}
#endif

#ifdef OPT_DEBUG
static void opt_block_dump(struct block *root) {
  int i, n;
  struct slist *s;

  unMarkAll();
  n = count_blocks(root);
  blocks = (struct block **)malloc(n * sizeof(*blocks));
  topsort(root);
  
  for (i = 0; i< n; i++) {
    struct block *p = blocks[i];
    printf("Block #%d\n", p->id);
    s = p->stmts;
    while(s != NULL) {
      char *text = opt_image(p, &s->s);
      if (text != NULL) printf("%s\n", text);
      s = s->next;
    }
    printf("%s\n\n", opt_image(p, &p->s));
  }
}
#endif
  

#ifdef OPT_DEBUG
static void
opt_dump(struct block *root)
{
	int len;
	struct bpf_insn* insns;

	memset(bids, 0, sizeof bids);
	insns = icode_to_fcode(root, &len);
	if (insns != 0) {
		bpf_dump(insns, len);
		printf("-\n");
		free((char *)insns);
	}
}
#endif

static void
opt_loop(struct block *root, int do_stmts)
{

#ifdef OPT_DEBUG
	if (dflag)
	  opt_block_dump(root);
#endif
	do {
		done = 1;
		topsort(root);
		find_dom(root);
		find_closure(root);
		find_inedges(root);
		find_ud(root);
		find_edom(root);
		find_value_numbering();
#ifdef OPT_DEBUG
		if (dflag)
		  opt_block_dump(root);
#endif
		total_redundancy_elimination();
#ifdef OPT_DEBUG
		if (dflag)
		  opt_block_dump(root);
#endif
		opt_blks(root, do_stmts); 
#ifdef OPT_DEBUG
		if (dflag)
			opt_block_dump(root);
#endif
	} while (!done);
}

/*
 * Optimize the filter code in its dag representation.
 */
void
bpf_optimize(rootp)
	struct block **rootp;
{
	struct block *root;

	root = *rootp;

#ifdef OPT_DEBUG
	if (dflag)
	  printf("opt_init\n");
#endif
	opt_init(root);
#ifdef OPT_DEBUG
	if (dflag)
	opt_block_dump(root);
#endif
	opt_loop(root, 0);
	opt_loop(root, 1);
	register_allocation(root);
	intern_blocks(root);
	opt_root(rootp);
#ifdef OPT_DEBUG
if (dflag) {
  printf("Ready for code linearization.\n");
  opt_block_dump(root);
}
#endif
	opt_cleanup();
}

void bpf_dont_optimize(struct block **rootp) {
  struct block *root;
  
  root = *rootp;

  opt_init(root);
#ifdef OPT_DEBUG
  if (dflag)
    opt_block_dump(root);
#endif
  topsort(root);
  find_closure(root);
  find_value_numbering();
  register_allocation(root);
  intern_blocks(root);
  opt_root(rootp);
#ifdef OPT_DEBUG
if (dflag) {
  printf("Ready for code linearization.\n");
  opt_block_dump(root);
}
#endif
  opt_cleanup();
}
  




  
  
