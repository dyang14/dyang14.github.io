/* 
 * Copyright �1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996,
 * 1997, 2001, 2004. The Regents of the University of California 
 * (Regents). All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research, and not-for-profit purposes,
 * without fee and without a signed licensing agreement, is hereby
 * granted, provided that the above copyright notice, this paragraph and
 * the following three paragraphs appear in all copies, modifications, and
 * distributions. Contact The Office of Technology Licensing, UC
 * Berkeley, 2150 Shattuck Avenue, Suite 510, Berkeley, CA 94720-1620,
 * (510) 643-7201, for commercial licensing opportunities. 
 *
 * This code is derived from the Stanford/CMU enet packet filter,
 * distributed as part of 4.3BSD, and code contributed to Berkeley by
 * Steven McCanne and Van Jacobson both of Lawrence Berkeley Laboratory,
 * and Andrew Begel of the Berkeley Computer Science Division of the
 * Electrical Engineering and Computer Science Department.
 * 
 * IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 * SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 * REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE. THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
 * ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO
 * OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS.
 *
 *	@(#)bpf.c	7.5 (Berkeley) 7/15/91
 *
 * static char rcsid[] =
 * "$Header: /usr/src/mash/repository/bpfl/bpf_assemble.c,v 1.2 1997/11/18 00:09:41 mccanne Exp $";
 */

u_char *bpf_emit_prologue(u_char *code, u_int* mem);
u_char *bpf_emit_l(u_char *code, int mode, int size, int rd, int rx, int op1);
u_char *bpf_emit_lm(u_char *code, int rd, int imm);
u_char *bpf_emit_lm_index(u_char *code, int rd, int rindex);
u_char *bpf_emit_sm(u_char *code, int rd, int imm);
u_char *bpf_emit_sm_index(u_char *code, int rs1, int rindex);
u_char *bpf_emit_alu_imm(u_char *code, int op, int ra, int imm, int rd);
u_char *bpf_emit_alu_reg(u_char *code, int op, int ra, int rb, int rd);
u_char *bpf_emit_ja(u_char *code);
u_char *bpf_emit_branch(u_char *code, int type, int rd, int imm);
u_char *bpf_emit_ret_imm(u_char *code, int imm);
u_char *bpf_emit_ret_reg(u_char *code, int reg);
u_char *bpf_emit_epilogue(u_char *code);
void bpf_patch_ja(u_char* branch, u_char* target);
void bpf_patch_branch(u_char* branch, u_char* target);
void bpf_patch_ret_imm(u_char* branch, u_char* epilogue);
void bpf_patch_ret_reg(u_char* branch, u_char* epilogue);
