/* 
 * Copyright �1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996,
 * 1997, 2001, 2004. The Regents of the University of California 
 * (Regents). All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research, and not-for-profit purposes,
 * without fee and without a signed licensing agreement, is hereby
 * granted, provided that the above copyright notice, this paragraph and
 * the following three paragraphs appear in all copies, modifications, and
 * distributions. Contact The Office of Technology Licensing, UC
 * Berkeley, 2150 Shattuck Avenue, Suite 510, Berkeley, CA 94720-1620,
 * (510) 643-7201, for commercial licensing opportunities. 
 *
 * This code is derived from the Stanford/CMU enet packet filter,
 * distributed as part of 4.3BSD, and code contributed to Berkeley by
 * Steven McCanne and Van Jacobson both of Lawrence Berkeley Laboratory,
 * and Andrew Begel of the Berkeley Computer Science Division of the
 * Electrical Engineering and Computer Science Department.
 * 
 * IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 * SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 * REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE. THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
 * ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO
 * OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS.
 *
 *      @(#)bpf.h       7.1 (Berkeley) 5/7/91
 *
 * @(#) $Header: /usr/src/mash/repository/bpfl/bpf.h,v 1.1.1.1 1997/11/17 22:09:16 mccanne Exp $ (LBL)
 */
#ifndef value_numbering_h
#define value_numbering_h

#include "gencode.h"

typedef union {
  struct {
    unsigned int imm;
  } imm;
  struct {
    unsigned int start;
    unsigned int length;
  } packet;
  struct {
    unsigned int start;
    unsigned int length;
    unsigned int reg;
  } packet_reg;
  struct {
    unsigned int location;
    unsigned int code;
    unsigned int reg;
  } mem;
  struct {
    int index;
  } copy;
  struct { 
    unsigned int reg1;
    unsigned int reg2;
    unsigned int code;
  } reg_reg;
  struct {
    unsigned int code;
    unsigned int imm;
    unsigned int reg;
  } reg_imm;
  struct {
    unsigned int imm;
    unsigned int reg;
  } jmp;
} instruction_type;

typedef struct {
  int type;
  instruction_type instr;
} instruction;


#define IT_UNDEFINED 0
#define IT_PACKET 1
#define IT_PACKET_REG 2
#define IT_MEM 3
#define IT_COPY 4
#define IT_REG_REG 5
#define IT_REG_IMM 6
#define IT_IMM 7
#define IT_JMP 8

typedef struct {
  unsigned int type;
  unsigned int place;
} destination;

#define DEST_UNDEFINED 0
#define DEST_REG 1
#define DEST_MEM 2
#define DEST_PACKET 3

/* this will be used to index into an array of valnodes */
typedef struct {
  destination dest;
  instruction instr;
  struct block *b;
  uset interference;
} valnode;

void init_val();
instruction valnum_instruction(struct stmt *s);
destination valnum_destination(struct stmt *s);
int valnum(destination d);
valnode *find_dest(destination d);
void erase_dest(destination d);
int is_constantp(instruction code);
valnode *find_earliest(struct stmt *s);
destination make_dest(unsigned int, unsigned int);
void insert_valnode(valnode);
valnode make_valnode(struct block *b, struct stmt *s);
int instruction_equalp(instruction, instruction);
valnode *find_valnode(int reg);

#endif
