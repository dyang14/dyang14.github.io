/* 
 * Copyright �1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996,
 * 1997, 2001, 2004. The Regents of the University of California 
 * (Regents). All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research, and not-for-profit purposes,
 * without fee and without a signed licensing agreement, is hereby
 * granted, provided that the above copyright notice, this paragraph and
 * the following three paragraphs appear in all copies, modifications, and
 * distributions. Contact The Office of Technology Licensing, UC
 * Berkeley, 2150 Shattuck Avenue, Suite 510, Berkeley, CA 94720-1620,
 * (510) 643-7201, for commercial licensing opportunities. 
 *
 * This code is derived from the Stanford/CMU enet packet filter,
 * distributed as part of 4.3BSD, and code contributed to Berkeley by
 * Steven McCanne and Van Jacobson both of Lawrence Berkeley Laboratory,
 * and Andrew Begel of the Berkeley Computer Science Division of the
 * Electrical Engineering and Computer Science Department.
 * 
 * IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 * SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 * REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE. THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
 * ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO
 * OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS.
 *
 *      @(#)bpf.h       7.1 (Berkeley) 5/7/91
 *
 * @(#) $Header: /usr/src/mash/repository/bpfl/bpf-vm.h,v 1.2 1997/11/18 00:09:40 mccanne Exp $ (LBL)
 */

#ifndef bpf_vm_h
#define bpf_vm_h

/*XXX*/
#define BPF_VM_VERSION 199710

/* Current version number of filter architecture. */
#define BPF_MAJOR_VERSION 2
#define BPF_MINOR_VERSION 0

#define BPF_MAXINSNS 512

struct bpf_program {
	u_int bf_len;
	struct bpf_insn *bf_insns;
};


/*
 * The instruction encondings.
 */
/* instruction classes */
#define BPF_CLASS(code) ((code) & 0x07)
#define		BPF_LD		0x00
#define		BPF_LDM		0x01
#define		BPF_STM		0x02
#define		BPF_ALU		0x03
#define		BPF_JMP		0x04
#define		BPF_RET		0x05

/* ld/st fields */
#define BPF_SIZE(code)	((code) & 0x18)
#define		BPF_B		0x00
#define		BPF_H		0x08
#define		BPF_W		0x10
#define BPF_MODE(code)	((code) & 0xe0)
#define		BPF_ABS		0x20
#define		BPF_IND		0x40

/* these modes must be clear of BPF_OP */
#define BPF_ALU_MODE(code)	((code) & 0x08)
#define		BPF_IMM		0x00
#define		BPF_REG		0x08
/* can use same bit for return mode */
#define BPF_RET_MODE(code)	((code) & 0x08)
#define BPF_JMP_MODE(code)	((code) & 0x08)

/* alu ops */
#define BPF_OP(code)	((code) & 0xf0)
#define		BPF_ADD		0x00
#define		BPF_SUB		0x10
#define		BPF_MUL		0x20
#define		BPF_DIV		0x30
#define		BPF_OR		0x40
#define		BPF_AND		0x50
#define		BPF_XOR		0x60
#define		BPF_LSH		0x70
#define		BPF_RSH		0x80
#define		BPF_NEG		0x90
#define         BPF_COPY        0xA0
/* jmp ops */
#define		BPF_JA		0x00
#define		BPF_JEQ		0x10
#define		BPF_JGT		0x20
#define		BPF_JGE		0x30
#define		BPF_JNE		(0x10|0x80)
#define		BPF_JLT		(0x20|0x80)
#define		BPF_JLE		(0x30|0x80)

typedef unsigned int u_int32_t;

/*
 * The instruction data structure.
 */
struct bpf_insn {
  u_int32_t op0;
  u_int32_t op1;
  //u_int32_t ra;
  //u_int32_t rb;
  //u_int32_t rd;
};
#define BPF_OFF(op0) (((op0) >> 10) & 0x3fff)
#define BPF_RD(op0) ((op0) & 0x1f)
#define BPF_RA(op0) (((op0) >> 5) & 0x1f)
#define BPF_RB(op0) (((op0) >> 10) & 0x1f)
#define BPF_SET_RD(regno) (regno)
#define BPF_SET_RA(regno) ((regno) << 5)
#define BPF_SET_RB(regno) ((regno) << 10)
#define BPF_SET_OFF(offset) (((offset) & 0x3fff) << 10)
/*
 * Macros for insn array initializers.
 */
#define BPF_STMT(code, k) { (u_short)(code), 0, 0, k }
#define BPF_JUMP(code, k, jt, jf) { (u_short)(code), jt, jf, k }

/*
 * Number of scratch memory words (for BPF_LDM and BPF_STM).
 */
#define BPF_MEMWORDS 32
#define BPF_NREG 4
#define BPF_ARCHREG 32

#endif
