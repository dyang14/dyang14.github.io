/* 
 * Copyright �1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996,
 * 1997, 2001, 2004. The Regents of the University of California 
 * (Regents). All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research, and not-for-profit purposes,
 * without fee and without a signed licensing agreement, is hereby
 * granted, provided that the above copyright notice, this paragraph and
 * the following three paragraphs appear in all copies, modifications, and
 * distributions. Contact The Office of Technology Licensing, UC
 * Berkeley, 2150 Shattuck Avenue, Suite 510, Berkeley, CA 94720-1620,
 * (510) 643-7201, for commercial licensing opportunities. 
 *
 * This code is derived from the Stanford/CMU enet packet filter,
 * distributed as part of 4.3BSD, and code contributed to Berkeley by
 * Steven McCanne and Van Jacobson both of Lawrence Berkeley Laboratory,
 * and Andrew Begel of the Berkeley Computer Science Division of the
 * Electrical Engineering and Computer Science Department.
 * 
 * IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 * SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 * REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE. THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
 * ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO
 * OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS.
 */

#if !(defined(lint) || defined(KERNEL))
static char rcsid[] =
    "@(#) $Header: /usr/src/mash/repository/bpfl/bpf_sparc.c,v 1.1.1.1 1997/11/17 22:09:16 mccanne Exp $ (LBL)";
#endif

#include <sys/param.h>
#include <sys/time.h>
#include <net/bpf.h>
#include "bpf_assemble.h"

//                save %o6, -0x60, %o6
#define SAVE_INSN 0x9de3bfa0

u_char *
bpf_emit_prologue(u_char *code, u_int* mem)
{
	u_int *cp = (u_int *)code;

	*cp++ = SAVE_INSN;
	ldconst(cp, REG_MEM, (u_int)mem); 

	return ((u_char *)cp);
}

#define FMT3_IMM(op, rd, op3, rs1, simm13) \
  ((op) << 30 | (rd) << 25 | (op3) << 19 | (rs1) << 14 | 1 << 13 | (simm13))
#define FMT3_REG(op, rd, op3, rs1, rs2) \
  ((op) << 30 | (rd) << 25 | (op3) << 19 | (rs1) << 14 | (rs2))

#define REG_PKT 	24	/* %i0 */
#define REG_WIRELEN 	25	/* %i1 */
#define REG_BUFLEN 	26	/* %i2 */
#define REG_S0		20	/* %l4 (scratch) */
#define REG_S1		21	/* %l5 (scratch) */
#define REG_I7		31
#define REG_RETURN	24	/* %i0 */
#define REG_O0		8	/* %o0 */
#define REG_O1		9	/* %o1 */
#define REG_MEM		10	/* %o2 */
#define REG_G0		0	/* %g0 */

/* sethi 0, %g0 */
#define NOP (1 << 24)

static u_int *
ldconst(u_int* cp, int rd, int imm)
{
	if (imm &~ 0xfff) {
		/* sethi */
		*cp++ = rd << 25 | 1 << 24 | imm >> 10;
		/* add */
		*cp++ = FMT3_IMM(2, rd, 0, rd, imm & 0x3ff);
	} else
		/* add 0, imm, rd */
		*cp++ = FMT3_IMM(2, rd, 0, 0, imm & 0xfff);

	return (cp);
}

/* #define KERNEL */
#ifdef KERNEL
void m_xbyte(){}/*XXX*/
void m_xhalf(){}
void m_xword(){}
void (*extractors[])() = {
	m_xbyte,
	m_xhalf,
	m_xword,
};
#endif

u_char *
bpf_emit_l(u_char *code, int mode, int size, int rd, int rx, int imm)
{
	u_int *cp = (u_int *)code;
	int i, n;

	size >>= 3;
	n = 1 << size;  /* number of bytes on work */

	/* convert to sparc locals (%l0,%l1,...) */
	rd += 16;
	rx += 16;

	if ((imm + n) &~ 0xfff) {
		/* XXX could handle this here, but it should never happen */
#ifdef KERNEL
		return (0);
#else
		abort();
#endif
	}
	if (mode == BPF_ABS) {
#ifdef KERNEL
		u_int off;
#endif
		/*
		 * cmp REG_BUFLEN, imm+n
		 * bge ok
		 *  mov 0,rd
		 * #ifdef KERNEL
		 * cmp REG_BUFLEN, 0
		 * bne out
		 * mov REG_PKT, %o0
		 * call m_xword/m_xhalf/m_xbyte
		 * mov imm, %o1
		 * mov %o0, rd
		 * #endif
		 * ja out
		 * ok:
		 * ldub [PKT_REG + imm], rd
		 * ldub [PKT_REG + imm+1], s0
		 * lsh rd, 8, rd
		 * or rd, s0, rd
		 * ...
		 * out:
		 */
		*cp++ = FMT3_IMM(2, 0, 0x14, REG_BUFLEN, imm+n);
#ifdef KERNEL
		*cp++ = 11 << 25 | 2 << 22 | 9; /* bge */
#else
		*cp++ = 11 << 25 | 2 << 22 | 3; /* bge */
#endif
		*cp++ = FMT3_REG(2, rd, 0, 0, 0);	  /* add g0,g0,rd*/
#ifdef KERNEL
		*cp++ = FMT3_IMM(2, 0, 0x14, REG_BUFLEN, 0);
		*cp++ = 9 << 25 | 2 << 22 | (4 + 3 * n); /* bne */
		*cp++ = FMT3_REG(2, REG_O0, 0, REG_G0, REG_PKT);
		off = (int)extractors[size] - (int)cp;
		*cp++ = 0x40000000 | (off >> 2);
		*cp++ = FMT3_IMM(2, REG_O1, 0, REG_G0, imm);
		*cp++ = 0 << 29 | 8 << 25 | 2 << 22 | (3 * n); /* ba */
		*cp++ = FMT3_REG(2, rd, 0, REG_G0, REG_O0);
#else
		*cp++ = 1 << 29 | 8 << 25 | 2 << 22 | (3 * n - 1); /* ba,a */
#endif
		*cp++ = FMT3_IMM(3, rd, 1, REG_PKT, imm); /* ldub */
		for (i = 1; i < n; ++i) {
			/* ldub */
			*cp++ = FMT3_IMM(3, REG_S0, 1, REG_PKT, imm + i);
			/* lsh */
			*cp++ = FMT3_IMM(2, rd, 0x25, rd, 8);
			/* or */
			*cp++ = FMT3_REG(2, rd, 0x02, REG_S0, rd);
		}
	} else if (mode == BPF_IND) {
		/*
		 * add rx,imm+n,s0
		 * cmp CAPLEN_REG, imm+n
		 * bge ok
		 *  add s0, -n, s0
		 * mov 0,rd
		 * #ifdef KERNEL
		 * cmp REG_BUFLEN, 0
		 * bne out
		 * mov REG_PKT, %o0
		 * call m_xword/m_xhalf/m_xbyte
		 * mov s0, %o1
		 * mov %o0, rd
		 * #endif
		 * ja out
		 * ok:
		 * ldub [PKT_REG + s0], rd
		 * add s0, 1, s0
		 * ldub [PKT_REG + s0], s0
		 * lsh rd, 8, rd
		 * or rd, s0, rd
		 * ...
		 * out:
		 */
		*cp++ = FMT3_IMM(2, REG_S1, 0, rx, imm + n);
		*cp++ = FMT3_IMM(2, 0, 0x14, REG_BUFLEN, imm+n);
#ifdef KERNEL
		*cp++ = 11 << 25 | 2 << 22 | 10; /* bge */
#else
		*cp++ = 11 << 25 | 2 << 22 | 4; /* bge */
#endif
		*cp++ = FMT3_IMM(2, REG_S1, 0, REG_S1, (-n) & 0x1fff);
		*cp++ = FMT3_REG(2, rd, 0, 0, 0);	  /* add g0,g0,rd*/
#ifdef KERNEL
		*cp++ = FMT3_IMM(2, 0, 0x14, REG_BUFLEN, 0);
		*cp++ = 9 << 25 | 2 << 22 | (4 + 3 * n); /* bne */
		*cp++ = FMT3_REG(2, REG_O0, 0, REG_G0, REG_PKT);
		off = (int)extractors[size] - (int)cp;
		*cp++ = 0x40000000 | (off >> 2);
		*cp++ = FMT3_REG(2, REG_O1, 0, REG_G0, REG_S0);
		*cp++ = 0 << 29 | 8 << 25 | 2 << 22 | (3 * n); /* ba */
		*cp++ = FMT3_REG(2, rd, 0, REG_G0, REG_O0);
#else
		*cp++ = 1 << 29 | 8 << 25 | 2 << 22 | (3 * n - 1); /* ba,a */
#endif
		*cp++ = FMT3_REG(3, rd, 1, REG_PKT, REG_S0); /* ldub */
		for (i = 1; i < n; ++i) {
			*cp++ = FMT3_IMM(2, REG_S0, 0, REG_S0, 1);
			/* ldub */
			*cp++ = FMT3_REG(3, REG_S0, 1, REG_PKT, REG_S1);
			/* lsh */
			*cp++ = FMT3_IMM(2, rd, 0x25, rd, 8);
			/* or */
			*cp++ = FMT3_REG(2, rd, 0x02, REG_S0, rd);
		}
	} else if (mode == BPF_IMM)
		cp = ldconst(cp, rd, imm);
	else
		abort();

	return ((u_char *)cp);
}

u_char *
bpf_emit_lm(u_char *code, int rd, int imm) 
{
  // lwz
  u_int *cp = (u_int *)code;
  int op3 = 0; // Load word;
  rd += 16;

  if (imm &~ 0xfff) {
    cp = ldconst(cp, REG_S0, imm);
    *cp++ = FMT3_REG(3, rd, op3, REG_MEM, REG_S0);
  }
  else {
    *cp++ = FMT3_IMM(3, rd, op3, REG_MEM, imm & 0xfff);
  return ((u_char *)cp);
}

u_char *
bpf_emit_sm(u_char *code, int rs1, int imm)
{
  // stw
  u_int *cp = (u_int *)code;
  int op3 = 4; // Store word;
  rs1 += 16;

  if (imm &~ 0xfff) {
    cp = ldconst(cp, REG_S0, imm);
    *cp++ = FMT3_REG(3, rs1, op3, REG_MEM, REG_S0);
  }
  else 
    *cp++ = FMT3_IMM(3, rs1, op3, REG_MEM, imm & 0xfff);
  return ((u_char *)cp);
  
}

u_char *
bpf_emit_lm_index(u_char *code, int rd, int rindex)
{
  // lwzx
  u_int *cp = (u_int *)code;
  int op3 = 0; // Load word;
  rd += 16;
  rindex += 16;

  *cp++ = FMT3_REG(3, rd, op3, REG_MEM, rindex);
  return ((u_char *)cp);
  
}


u_char *
bpf_emit_sm_index(u_char *code, int rd, int rindex)
{
  // stwx
  u_int *cp = (u_int *)code;
  int op3 = 4; // Store word;
  rd += 16;
  rindex += 16;

  *cp++ = FMT3_REG(3, rd, op3, REG_MEM, rindex);
  return ((u_char *)cp);
  
}


static int aluop3[] = {
	/* add */ 0, 
	/* sub */ 4, 
	/* mul */ -1,
	/* div */ -1,
	/* or */ 2,
	/* and */ 1,
	/* xor */ -1/*XXX*/,
	/* lsh */ 0x25,
	/* rsh */ 0x26,
	/* neg */ -1,
};

u_char *
bpf_emit_alu_imm(u_char *code, int op, int ra, int imm, int rd)
{
	u_int *cp = (u_int *)code;
	int op3 = aluop3[op >> 4];
	if (op3 < 0)
		abort();

	rd += 16;
	ra += 16;
	if (imm &~ 0xfff) {
		cp = ldconst(cp, REG_S0, imm);
		*cp++ = FMT3_REG(2, rd, op3, ra, REG_S0);
	} else 
		*cp++ = FMT3_IMM(2, rd, op3, ra, imm & 0xfff);

	return ((u_char *)cp);
}

u_char *
bpf_emit_alu_reg(u_char *code, int op, int ra, int rb, int rd)
{
	u_int *cp = (u_int *)code;
	int op3 = aluop3[op >> 4];

	if (op3 < 0)
		abort();
	rd += 16;
	ra += 16;
	rb += 16;
	*cp++ = FMT3_REG(2, rd, op3, ra, rb);
	return ((u_char *)cp);
}

u_char *
bpf_emit_ja(u_char *code)
{
	u_int *cp = (u_int *)code;
	*cp++ = 1 << 29 | 8 << 25 | 2 << 22; /* ba,a */
	return ((u_char *)cp);
}

u_char *
bpf_emit_branch(u_char *code, int type, int rd, int imm)
{
	int t, cond;
	u_int *cp = (u_int *)code;

	rd += 16;
	cp = ldconst(cp, rd, imm);

	t = type & 0x7f;
	if (t == BPF_JEQ)
		cond = 1;
	else if (t == BPF_JGT)
		cond = 12;
	else
		/* BPF_JGE (bcc = bgeu) */
		cond = 5;

	if (type & 0x80)
		/* invert sense */
		cond ^= 8;
		
	*cp++ = cond << 25 | 2 << 22; /* bicc */
	*cp++ = NOP;

	return ((u_char *)cp);
}

u_char *
bpf_emit_ret_imm(u_char *code, int imm)
{
	u_int *cp = (u_int *)code;
	
	cp = ldconst(cp, REG_RETURN, imm);
	/* ret (jmpl %i7+8,%g0) */
	*cp++ = FMT3_IMM(2, 0, 0x38, REG_I7, 8);
	/* restore (%g0,%g0,%g0) */
	*cp++ = FMT3_REG(2, 0, 0x3d, 0, 0);

	return ((u_char *)cp);
}

u_char *
bpf_emit_ret_reg(u_char *code, int rd)
{
	u_int *cp = (u_int *)code;
	
	rd += 16;
	/* add rd, %g0, rr */
	*cp++ = FMT3_REG(2, REG_RETURN, 0, rd, 0);
	/* ret (jmpl %i7+8,%g0) */
	*cp++ = FMT3_IMM(2, 0, 0x38, REG_I7, 8);
	/* restore (%g0,%g0,%g0) */
	*cp++ = FMT3_REG(2, 0, 0x3d, 0, 0);

	return ((u_char *)cp);
}

u_char *
bpf_emit_epilogue(u_char *code)
{
	/* don't need one */
	return (code);
}

void 
bpf_patch_ja(u_char* insn, u_char* target)
{
	int off = (target - insn) >> 2;
	*(u_int *)insn |= off;
}

void 
bpf_patch_branch(u_char* insn, u_char* target)
{
	/*
	 *the first bit tells us if we had to use 1 or 2 insns to load
	 * the constant comparison value.
	 */
	insn += (*insn & 0x80) ? 4 : 8;
	bpf_patch_ja(insn, target);
}

void 
bpf_patch_ret_imm(u_char* insn, u_char* epilogue)
{
}

void 
bpf_patch_ret_reg(u_char* insn, u_char* epilogue)
{
}

