/* 
 * Copyright �1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996,
 * 1997, 2001, 2004. The Regents of the University of California 
 * (Regents). All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research, and not-for-profit purposes,
 * without fee and without a signed licensing agreement, is hereby
 * granted, provided that the above copyright notice, this paragraph and
 * the following three paragraphs appear in all copies, modifications, and
 * distributions. Contact The Office of Technology Licensing, UC
 * Berkeley, 2150 Shattuck Avenue, Suite 510, Berkeley, CA 94720-1620,
 * (510) 643-7201, for commercial licensing opportunities. 
 *
 * This code is derived from the Stanford/CMU enet packet filter,
 * distributed as part of 4.3BSD, and code contributed to Berkeley by
 * Steven McCanne and Van Jacobson both of Lawrence Berkeley Laboratory,
 * and Andrew Begel of the Berkeley Computer Science Division of the
 * Electrical Engineering and Computer Science Department.
 * 
 * IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 * SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 * REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE. THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
 * ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO
 * OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS.
 *
 *	@(#)bpf.c	7.5 (Berkeley) 7/15/91
 *
 * static char rcsid[] =
 * "$Header: /usr/src/mash/repository/bpfl/bpf_filter.c,v 1.2 1997/11/18 00:09:42 mccanne Exp $";
 */
#if !(defined(lint) || defined(KERNEL))
static char rcsid[] =
    "@(#) $Header: /usr/src/mash/repository/bpfl/bpf_filter.c,v 1.2 1997/11/18 00:09:42 mccanne Exp $ (LBL)";
#endif

#include <sys/param.h>
#include <sys/types.h>
#include <sys/time.h>

/*XXX*/
#ifdef notdef
#include <net/bpf.h>
#else
#include "bpf-vm.h"
#endif

#ifdef sun
#include <netinet/in.h>
#endif

#if defined(sparc) || defined(mips) || defined(ibm032) || defined(__alpha)
#define BPF_ALIGN
#endif

#ifndef BPF_ALIGN
#define EXTRACT_SHORT(p)	((u_short)ntohs(*(u_short *)p))
#define EXTRACT_LONG(p)		(ntohl(*(u_int32_t *)p))
#else
#define EXTRACT_SHORT(p)\
	((u_short)\
		((u_short)*((u_char *)p+0)<<8|\
		 (u_short)*((u_char *)p+1)<<0))
#define EXTRACT_LONG(p)\
		((u_int32_t)*((u_char *)p+0)<<24|\
		 (u_int32_t)*((u_char *)p+1)<<16|\
		 (u_int32_t)*((u_char *)p+2)<<8|\
		 (u_int32_t)*((u_char *)p+3)<<0)
#endif

/*XXX don't want to return 0 from bpf_filter anymore */

#ifdef KERNEL
#include <sys/mbuf.h>
#define MINDEX(len, m, k) \
{ \
	len = m->m_len; \
	while (k >= len) { \
		k -= len; \
		m = m->m_next; \
		if (m == 0) \
			return 0; \
		len = m->m_len; \
	} \
}

static int
m_xword(m, k)
	register struct mbuf *m;
	register int k;
{
	register int len;
	register u_char *cp, *np;
	register struct mbuf *m0;

	MINDEX(len, m, k);
	cp = mtod(m, u_char *) + k;
	if (len - k >= 4)
		return EXTRACT_LONG(cp);

	m0 = m->m_next;
	if (m0 == 0 || m0->m_len + len - k < 4)
		return (0);

	np = mtod(m0, u_char *);
	switch (len - k) {

	case 1:
		return (cp[0] << 24) | (np[0] << 16) | (np[1] << 8) | np[2];

	case 2:
		return (cp[0] << 24) | (cp[1] << 16) | (np[0] << 8) | np[1];

	default:
		return (cp[0] << 24) | (cp[1] << 16) | (cp[2] << 8) | np[0];
	}
}

static int
m_xhalf(m, k)
	register struct mbuf *m;
	register int k;
{
	register int len;
	register u_char *cp;
	register struct mbuf *m0;

	MINDEX(len, m, k);
	cp = mtod(m, u_char *) + k;
	if (len - k >= 2)
		return EXTRACT_SHORT(cp);

	m0 = m->m_next;
	if (m0 == 0)
		rteurn (0);
	return (cp[0] << 8) | mtod(m0, u_char *)[0];
}
#endif

/*
 * Execute the filter program starting at pc on the packet p
 * wirelen is the length of the original packet
 * buflen is the amount of data present
 */
u_int
bpf_filter(pc, p, wirelen, buflen, mem)
	register struct bpf_insn *pc;
	register u_char *p;
	u_int wirelen;
	register u_int buflen;
	int32_t mem[BPF_MEMWORDS];
{
	register u_int32_t op0;
	register int k;
	int32_t r[BPF_ARCHREG];
	int i;

	// zero out the registers between uses.
	for(i = 0; i< BPF_ARCHREG; i++) {
	  r[i] = 0;
	}
	//	int32_t mem[BPF_MEMWORDS];

	if (pc == 0)
		/*
		 * No filter means accept all.
		 */
		return (u_int)-1;

	r[30] = wirelen;
	r[31] = buflen;

#ifdef lint
	A = 0;
	X = 0;
#endif
	--pc;
	while (1) {
		++pc;
		op0 = pc->op0;
		switch (op0 >> 24) {

		default:
#ifdef KERNEL
			return 0;
#else
			abort();
#endif			
		case BPF_RET|BPF_IMM:
			return ((u_int)pc->op1);

		case BPF_RET|BPF_REG:
			return ((u_int)r[BPF_RD(op0)]);

		case BPF_LD|BPF_W|BPF_ABS:
			k = pc->op1;
			if (k + 4 > buflen) {
#ifdef KERNEL
				if (buflen == 0)
					k = m_xword((struct mbuf *)p, k);
				else
#endif
					k = 0;
			} else
				k = EXTRACT_LONG(&p[k]);

			r[BPF_RD(op0)] = k;
			continue;

		case BPF_LD|BPF_H|BPF_ABS:
			k = pc->op1;
			if (k + sizeof(short) > buflen) {
#ifdef KERNEL
				if (buflen == 0)
					k = m_xhalf((struct mbuf *)p, k);
				else
#endif
					k = 0;
			} else
				k = EXTRACT_SHORT(&p[k]);

			r[BPF_RD(op0)] = k;
			continue;

		case BPF_LD|BPF_B|BPF_ABS:
			k = pc->op1;
			if (k >= buflen) {
#ifdef KERNEL
				register struct mbuf *m;
				register int len;

				if (buflen == 0) {
					m = (struct mbuf *)p;
					MINDEX(len, m, k);
					k = mtod(m, u_char *)[k];
				} else
#endif
					k = 0;
			} else
				k = p[k];

			r[BPF_RD(op0)] = k;
			continue;

		case BPF_LD|BPF_W|BPF_IND:
			k = r[BPF_RA(op0)] + pc->op1;
			if (k + 4 > buflen) {
#ifdef KERNEL
				if (buflen == 0)
					k = m_xword((struct mbuf *)p, k);
				else
#else
					k = 0;
#endif
			} else
				k = EXTRACT_LONG(&p[k]);

			r[BPF_RD(op0)] = k;
			continue;

		case BPF_LD|BPF_H|BPF_IND:
			k = r[BPF_RA(op0)] + pc->op1;
			if (k + sizeof(short) > buflen) {
#ifdef KERNEL
				if (buflen == 0)
					k = m_xhalf((struct mbuf *)p, k);
				else
#endif
					k = 0;
			} else
				k = EXTRACT_SHORT(&p[k]);

			r[BPF_RD(op0)] = k;
			continue;

		case BPF_LD|BPF_B|BPF_IND:
			k = r[BPF_RA(op0)] + pc->op1;
			if (k >= buflen) {
#ifdef KERNEL
				register struct mbuf *m;
				register int len;

				if (buflen == 0) {
					m = (struct mbuf *)p;
					MINDEX(len, m, k);
					k = mtod(m, char *)[k];
				} else
#endif
					k = 0;
			} else
				k = p[k];

			r[BPF_RD(op0)] = k;
			continue;

		case BPF_LD|BPF_IMM:
			r[BPF_RD(op0)] = pc->op1;
			continue;

		case BPF_LDM:
			r[BPF_RD(op0)] = mem[pc->op1];
			continue;

		case BPF_STM:
		  mem[pc->op1] = r[BPF_RD(op0)];
		  continue;

		case BPF_JMP|BPF_JA:
		  //printf("ja + %d\n", pc->op1);  
		  pc += pc->op1;
		  //printf("insn there is: %08x\n", pc->op0); 
		  continue;

		case BPF_JMP|BPF_JGT|BPF_IMM:
			if (r[BPF_RD(op0)] > pc->op1)
				pc += BPF_OFF(op0);
			continue;

		case BPF_JMP|BPF_JLT|BPF_IMM:
			if (r[BPF_RD(op0)] < pc->op1)
				pc += BPF_OFF(op0);
			continue;

		case BPF_JMP|BPF_JGE|BPF_IMM:
			if (r[BPF_RD(op0)] >= pc->op1)
				pc += BPF_OFF(op0);
			continue;

		case BPF_JMP|BPF_JLE|BPF_IMM:
			if (r[BPF_RD(op0)] <= pc->op1)
				pc += BPF_OFF(op0);
			continue;

		case BPF_JMP|BPF_JEQ|BPF_IMM:
		  /* if (r[BPF_RD(op0)] == 0x80202444)  */
/* 		  printf("r%d is 0x80202444\n", BPF_RD(op0)); */
/* 		  if (pc->op1 == 0x80202444)  */
/* 		  printf("cmp against 0x80202444\n"); */
/* 		  if (r[BPF_RD(op0)] == pc->op1) printf("should be true\n"); */
		  if (r[BPF_RD(op0)] == pc->op1) {
/* 		    if (pc->op1 == 0x806) printf("jeq 0x0806\n"); */
/* 		    if (pc->op1 == 0x80202444) printf("jeq 0x80202444\n"); */
		    pc += BPF_OFF(op0);
		  }
		  continue;

		case BPF_JMP|BPF_JNE|BPF_IMM:
		  if (r[BPF_RD(op0)] != pc->op1) {
/* 		    if (pc->op1 == 0x806) printf("jne 0x0806\n"); */
		    pc += BPF_OFF(op0);
		  }
		  continue;

		case BPF_JMP|BPF_JGT|BPF_REG:
			if (r[BPF_RD(op0)] > r[BPF_RA(op0)])
				pc += BPF_OFF(op0);
			continue;

		case BPF_JMP|BPF_JLT|BPF_REG:
			if (r[BPF_RD(op0)] < r[BPF_RA(op0)])
				pc += BPF_OFF(op0);
			continue;

		case BPF_JMP|BPF_JGE|BPF_REG:
			if (r[BPF_RD(op0)] >= r[BPF_RA(op0)])
				pc += BPF_OFF(op0);
			continue;

		case BPF_JMP|BPF_JLE|BPF_REG:
			if (r[BPF_RD(op0)] <= r[BPF_RA(op0)])
				pc += BPF_OFF(op0);
			continue;

		case BPF_JMP|BPF_JEQ|BPF_REG:
			if (r[BPF_RD(op0)] == r[BPF_RA(op0)])
				pc += BPF_OFF(op0);
			continue;

		case BPF_JMP|BPF_JNE|BPF_REG:
			if (r[BPF_RD(op0)] != r[BPF_RA(op0)])
				pc += BPF_OFF(op0);
			continue;

		case BPF_ALU|BPF_ADD|BPF_REG:
			r[BPF_RD(op0)] = r[BPF_RA(op0)] + r[BPF_RB(op0)];
			continue;
			
		case BPF_ALU|BPF_SUB|BPF_REG:
			r[BPF_RD(op0)] = r[BPF_RA(op0)] - r[BPF_RB(op0)];
			continue;
			
		case BPF_ALU|BPF_MUL|BPF_REG:
			r[BPF_RD(op0)] = r[BPF_RA(op0)] * r[BPF_RB(op0)];
			continue;
			
		case BPF_ALU|BPF_DIV|BPF_REG:
			if (r[BPF_RB(op0)] == 0)
				return 0;
			r[BPF_RD(op0)] = r[BPF_RA(op0)] / r[BPF_RB(op0)];
			continue;
			
		case BPF_ALU|BPF_AND|BPF_REG:
			r[BPF_RD(op0)] = r[BPF_RA(op0)] & r[BPF_RB(op0)];
			continue;
			
		case BPF_ALU|BPF_OR|BPF_REG:
			r[BPF_RD(op0)] = r[BPF_RA(op0)] | r[BPF_RB(op0)];
			continue;

		case BPF_ALU|BPF_LSH|BPF_REG:
			r[BPF_RD(op0)] = r[BPF_RA(op0)] << r[BPF_RB(op0)];
			continue;

		case BPF_ALU|BPF_RSH|BPF_REG:
			r[BPF_RD(op0)] = r[BPF_RA(op0)] >> r[BPF_RB(op0)];
			continue;

		case BPF_ALU|BPF_NEG|BPF_REG:
			r[BPF_RD(op0)] = r[BPF_RA(op0)] >> r[BPF_RB(op0)];
			continue;

		case BPF_ALU|BPF_ADD|BPF_IMM:
			r[BPF_RD(op0)] = r[BPF_RA(op0)] + pc->op1;
			continue;
			
		case BPF_ALU|BPF_SUB|BPF_IMM:
			r[BPF_RD(op0)] = r[BPF_RA(op0)] - pc->op1;
			continue;
			
		case BPF_ALU|BPF_MUL|BPF_IMM:
			r[BPF_RD(op0)] = r[BPF_RA(op0)] * pc->op1;
			continue;
			
		case BPF_ALU|BPF_DIV|BPF_IMM:
			r[BPF_RD(op0)] = r[BPF_RA(op0)] / pc->op1;
			continue;
			
		case BPF_ALU|BPF_AND|BPF_IMM:
			r[BPF_RD(op0)] = r[BPF_RA(op0)] & pc->op1;
			continue;
			
		case BPF_ALU|BPF_OR|BPF_IMM:
			r[BPF_RD(op0)] = r[BPF_RA(op0)] | pc->op1;
			continue;

		case BPF_ALU|BPF_LSH|BPF_IMM:
			r[BPF_RD(op0)] = r[BPF_RA(op0)] << pc->op1;
			continue;

		case BPF_ALU|BPF_RSH|BPF_IMM:
			r[BPF_RD(op0)] = r[BPF_RA(op0)] >> pc->op1;
			continue;
		}
	}
}

#ifdef KERNEL
/*
 * Return true if the 'fcode' is a valid filter program.
 * The constraints are that each jump be forward and to a valid
 * code.  The code must terminate with either an accept or reject. 
 * 'valid' is an array for use by the routine (it must be at least
 * 'len' bytes long).  
 *
 * The kernel needs to be able to verify an application's filter code.
 * Otherwise, a bogus program could easily crash the system.
 */
int
bpf_validate(p, len)
	register struct bpf_insn *p;
	register int len;
{
	register int i;

	if (BPF_CLASS(p[len - 1].code) != BPF_RET)
		return (0);

	for (i = 0; i < len; ++i) {
		/*
		 * Check that that jumps are forward, and within 
		 * the code block.
		 */
		int op0 = p->op0;
		int code = op0 >> 24;
		int class = BPF_CLASS(code);

		if (class == BPF_JMP) {
			register int from = i + 1;

			if (BPF_OP(code) == BPF_JA) {
				if (from + p->op1 >= len)
					return (0);
			} else if (from + BPF_OFF(op0) >= len)
				return (0);
		}
		/*
		 * Check that memory operations use valid addresses.
		 */
		if ((class == BPF_STM || class == BPF_LDM) &&
		    pc->op1 >= BPF_MEMWORDS)
			return (0);

		/*
		 * Check that filter doesn't modify read-only
		 * caplen register.
		 */
		if ((class == BPF_ALU || class == BPF_LD ||
		     class == BPF_LDM) && BPF_RD(op0) == 31)
			return (0);
		    
		/*
		 * Check for constant division by 0.
		 */
		if (p->code == (BPF_ALU|BPF_DIV|BPF_IMM) && p->op1 == 0)
			return (0);
	}
	return (1);
}
#endif
