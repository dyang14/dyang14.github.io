using Graphics;

namespace Study {

public class Drawing {

    public static void Main(string[] args) {

        Circle c = new Circle();
        Triangle t1 = new Triangle();
        Square s = new Square();
        Triangle t2 = new Triangle();

        Graphics.draw(t2);
        Graphics.draw(t1);
        Graphics.draw(c);
        Graphics.draw(s);
    
    }
}}


/*
    *
    * What are the last three shape objects drawn by Main()?
    *
    * (a) circle, triangle, square
    * (b) triangle, square, circle
    * (c) circle, triangle, triangle
    * (d) triangle, circle, square
    * (e) triangle, triangle, square
    *
    */
