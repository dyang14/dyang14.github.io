using Graphics;

namespace Study {

public class Drawing {

    public static void Main(string[] args) {
        Object[] array = new Object[10];
        
        Object o = new Circle();
        array.add(o);
        o = new Square();
        array.add(o);
        o = new Triangle();
        array.add(o);
        o = new Square();
        array.add(o);
        
        int i = 1;
        int temp = 10;

        while (i < 5) {
            temp = temp % 3;
            Graphics.draw(array[temp]);
            temp = temp + 2;
            i++;    
        }
    }
}}

/*
    *
    * What are the last three shape objects drawn by Main()?
    *
    * (a) triangle, square, circle
    * (b) square, square, triangle
    * (c) square, circle, square
    * (d) circle, triangle, square
    * (e) circle, square, triangle
    *
    */
