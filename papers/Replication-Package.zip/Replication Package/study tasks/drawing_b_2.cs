                                        using Graphics;

                                        namespace Study {

                                        public class Drawing {

                                            public static void Main(string[] args) {

                                                Object objectA = new Circle();
                                                Object objectK = new Circle();
                                                Object objectX = new Square();
                                                Object objectB = new Triangle();

                                                Graphics.draw(objectX);
                                                Graphics.draw(objectA);
                                                Graphics.draw(objectB);
                                                Graphics.draw(objectK);
    
                                            }
                                        }}


                                        /*
                                         *
                                         * What are the last three shape objects drawn by Main()?
                                         *
                                         * (a) circle, triangle, circle
                                         * (b) circle, triangle, square
                                         * (c) triangle, circle, circle
                                         * (d) triangle, square, circle
                                         * (e) triangle, circle, square
                                         *
                                         */
