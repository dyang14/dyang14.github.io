using Graphics;

namespace Study {

public class Drawing {

    public static void Main(string[] args) {
        Object[] array = new Object[10];
                
        array.add(new Triangle());
        array.add(new Circle());
        array.add(new Square());
        array.add(new Circle());
        
        swap(array, 3, 2);
        
        for (int l=0; l<3; l++) {
            Graphics.draw(array[l]);
        }
    }
    
    public static void swap(Object[] array, int i, int j) {
        Object temp = array[j];
        array[i] = array[j];
        array[j] = temp;
    }
}}

/*
 *
 * What are the last three shape objects drawn by Main()?
 *
 * (a) triangle, circle, circle
 * (b) circle, square, triangle
 * (c) triangle, circle, square
 * (d) circle, circle, square
 * (e) square, circle, triangle
 *
 */

