                                                using Graphics;

                                                using Graphics;

                                                namespace Study {

                                                public class Drawing {

                                                    public static void Main(string[] args) {
                                                        Object[] array = new Object[10];
        
                                                        Circle c = new Circle();
                                                        Triangle t1 = new Triangle();
                                                        Square s = new Square();
                                                        Triangle t2 = new Triangle();
                                                        array.add(t1);
                                                        array.add(c);
                                                        array.add(s);
                                                        array.add(t2);
        
                                                        for (int i=0; i<3; i++) {
                                                            Graphics.draw(array[i]);
                                                        }
                                                    }
                                                }}


                                                /*
                                                 *
                                                 * What are the last three shape objects drawn by Main()?
                                                 *
                                                 * (a) circle, triangle, square
                                                 * (b) triangle, square, triangle
                                                 * (c) triangle, circle, square
                                                 * (d) circle, square, triangle
                                                 * (e) none of the above
                                                 *
                                                 */
