                                                using Graphics;

                                                namespace Study {

                                                public class Drawing {

                                                    public static void Main(string[] args) {
                                                        Object[] array = new Object[10];

                                                        int temp1 = 21;
                                                        int temp2 = 11;
              
                                                        array.add(new Triangle());
                                                        array.add(new Square());
                                                        array.add(new Triangle());
                                                        Object o = (17 >= temp1) ? ((temp2 > 17) ? new Triangle() : new Square()) : ((temp1 < temp2) ? new Circle() : new Square());
                                                        array.add(o);   
        
                                                        for (int i=1; i<4; i++) {
                                                            Graphics.draw(array[i]);
                                                        }
                                                    }
                                                }}

                                                /*
                                                 *
                                                 * What are the last three shape objects drawn by Main()?
                                                 *
                                                 * (a) triangle, square, triangle
                                                 * (b) circle, square, circle
                                                 * (c) square, triangle, triangle
                                                 * (d) square, triangle, square
                                                 * (e) square, triangle, circle
                                                 *
                                                 */

