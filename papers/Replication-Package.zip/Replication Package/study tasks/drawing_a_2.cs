using Graphics;

namespace Study {

public class Drawing {

    public static void Main(string[] args) {
        Rectangle v = new Rectangle();
        v.leftTop = new Point(1,8);
        Rectangle x = new Rectangle();
        x.rightBottom = new Point(13,3);
        x.rightTop = new Point(13,10);
        x.leftBottom = new Point(7,3);
        v.rightTop = new Point(3,8);
        x.leftTop = new Point(7,10);
        v.rightBottom = new Point(3,5);
        Graphics.draw(x);   
        v.leftBottom = new Point(1,5);                   
        Graphics.draw(v);
    }    
}}

Will the two drawn rectangles overlap? yes / no