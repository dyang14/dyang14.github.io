using Graphics;

namespace Study {

public class Drawing {

    public static void Main(string[] args) {
        Rectangle t = new Rectangle();
        t.leftBottom = new Point(2,2);
        t.leftTop = new Point(2,6);
        t.rightTop = new Point(6,6);
        t.rightBottom = new Point(6,2);                   
        Graphics.draw(t);

        Rectangle s = new Rectangle();
        s.leftTop = new Point(11,5);
        s.leftBottom = new Point(5,5);
        s.rightBottom = new Point(5,9);
        s.rightTop = new Point(11,9);
        Graphics.draw(s);   
        
    }
}}

Will the two drawn rectangles overlap? yes / no