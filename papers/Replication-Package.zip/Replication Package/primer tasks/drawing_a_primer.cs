using Graphics;

namespace Study {

    public class Drawing {

        public static void Main(string[] args) {
            Rectangle r1 = new Rectangle();
            r1.leftBottom = new Point(6,6);
            r1.leftTop = new Point(6,10);
            r1.rightTop = new Point(11,10);
            r1.rightBottom = new Point(11,6);
            Graphics.draw(r1);
                   
            Rectangle r2 = new Rectangle();
            r2.leftBottom = new Point(1,1);
            r2.leftTop = new Point(1,8);
            r2.rightBottom = new Point(3,1);
            r2.rightTop = new Point(3,8);
            Graphics.draw(r2);   
        }
    }}

    Will the two drawn rectangles overlap? yes / no