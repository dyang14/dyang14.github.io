using Graphics;

namespace Study {

public class Drawing {

    public static void Main(string[] args) {
        
        Circle c = new Circle();
        Graphics.draw(c);

        Square s1 = new Square();
        Graphics.draw(s1);

        Triangle t = new Triangle();
        Graphics.draw(t);

        Square s2 = new Square();
        Graphics.draw(s2);
    }
}}

/*
    *
    * What are the last three shape objects drawn by Main()?
    *
    * (a) square, triangle, square
    * (b) triangle, square, circle
    * (c) square, square, triangle
    * (d) circle, square, triangle
    * (e) none of the above
    *
    */
